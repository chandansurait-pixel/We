import React, { useState, useEffect, useMemo } from 'react';
import { Product, CartItem, FilterState, Size, ProductColor, OrderConfirmation } from './types';
import { PRODUCTS, VALID_COUPONS } from './data/products';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { FilterBar } from './components/FilterBar';
import { FilterDrawer } from './components/FilterDrawer';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { LookbookSection } from './components/LookbookSection';
import { TrustBanner } from './components/TrustBanner';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { AdminPanel } from './components/AdminPanel';
import { 
  initializeProductsIfNeeded, 
  subscribeToProducts, 
  saveOrderToFirebase 
} from './services/firebase';
import { ShoppingBag, Heart, Sparkles, Check, ArrowRight } from 'lucide-react';

export default function App() {
  // Live dynamic products list synced with Firebase
  const [products, setProducts] = useState<Product[]>(PRODUCTS);
  const [adminOpen, setAdminOpen] = useState(false);
  // Local storage persisted state
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('lb_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('lb_wishlist');
      return saved ? JSON.parse(saved) : ['lb-top-01', 'lb-top-03'];
    } catch {
      return ['lb-top-01', 'lb-top-03'];
    }
  });

  // Filter state
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    subCategory: '',
    sizes: [],
    colors: [],
    priceRange: [600, 1500],
    fitType: '',
    sortBy: 'featured',
    inStockOnly: false,
  });

  // UI Drawer / Modal states
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [wishlistDrawerOpen, setWishlistDrawerOpen] = useState(false);
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [gridCols, setGridCols] = useState<1 | 2 | 3 | 4>(2);

  // Cart Add-ons & Coupons
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [giftWrap, setGiftWrap] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem('lb_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error(e);
    }
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem('lb_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {
      console.error(e);
    }
  }, [wishlistIds]);

  // Synchronize with Firebase Realtime Database
  useEffect(() => {
    initializeProductsIfNeeded(PRODUCTS);

    const unsub = subscribeToProducts((liveList) => {
      if (liveList && liveList.length > 0) {
        setProducts(liveList);
      }
    });

    if (window.location.hash === '#admin' || window.location.search.includes('admin=true')) {
      setAdminOpen(true);
    }

    return () => {
      if (unsub) unsub();
    };
  }, []);

  // Toast feedback helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2400);
  };

  // Wishlist handler
  const handleToggleWishlist = (productId: string) => {
    setWishlistIds((prev) => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Removed from wishlist');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('Added to wishlist ❤️');
        return [...prev, productId];
      }
    });
  };

  // Add to Cart
  const handleAddToCart = (
    product: Product,
    selectedSize: Size,
    selectedColor: ProductColor,
    quantity: number = 1
  ) => {
    setCartItems((prev) => {
      const existingIdx = prev.findIndex(
        (item) =>
          item.productId === product.id &&
          item.selectedSize === selectedSize &&
          item.selectedColor.name === selectedColor.name
      );

      if (existingIdx > -1) {
        const next = [...prev];
        next[existingIdx].quantity += quantity;
        return next;
      } else {
        const newItem: CartItem = {
          id: `${product.id}-${selectedSize}-${selectedColor.name}-${Date.now()}`,
          productId: product.id,
          product,
          selectedSize,
          selectedColor,
          quantity,
        };
        return [...prev, newItem];
      }
    });

    showToast(`Added ${product.name} (${selectedSize}) to bag!`);
    setCartDrawerOpen(true);
  };

  // Quick Add helper from product card
  const handleQuickAddToCart = (product: Product, size: Size) => {
    const defaultColor = product.colors[0];
    handleAddToCart(product, size, defaultColor, 1);
  };

  // Buy Now instant direct checkout
  const handleBuyNow = (
    product: Product,
    size: Size,
    color: ProductColor,
    quantity: number
  ) => {
    handleAddToCart(product, size, color, quantity);
    setSelectedProduct(null);
    setCartDrawerOpen(false);
    setCheckoutModalOpen(true);
  };

  // Cart item quantity update
  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  // Remove cart item
  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
    showToast('Item removed from bag');
  };

  // Apply Coupon
  const handleApplyCoupon = (code: string): boolean => {
    const rawSubtotal = cartItems.reduce(
      (acc, item) => acc + item.product.price * item.quantity,
      0
    );
    const valid = VALID_COUPONS[code];
    if (valid) {
      if (rawSubtotal >= valid.minSpend) {
        setAppliedCoupon(code);
        showToast(`Coupon ${code} applied successfully!`);
        return true;
      }
    }
    return false;
  };

  // Reset Filters
  const handleResetFilters = () => {
    setFilters({
      searchQuery: '',
      subCategory: '',
      sizes: [],
      colors: [],
      priceRange: [600, 1500],
      fitType: '',
      sortBy: 'featured',
      inStockOnly: false,
    });
  };

  // Filtered and Sorted Products
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Search
      if (filters.searchQuery.trim()) {
        const q = filters.searchQuery.toLowerCase();
        const matchesName = product.name.toLowerCase().includes(q);
        const matchesCategory = product.subCategory.toLowerCase().includes(q);
        const matchesDesc = product.description.toLowerCase().includes(q);
        if (!matchesName && !matchesCategory && !matchesDesc) return false;
      }

      // SubCategory
      if (filters.subCategory && filters.subCategory !== 'All Tops') {
        if (product.subCategory !== filters.subCategory) return false;
      }

      // Sizes
      if (filters.sizes.length > 0) {
        const hasMatchingSizeInStock = filters.sizes.some(
          (s) => product.sizes.includes(s) && (product.sizeStock[s] ?? 0) > 0
        );
        if (!hasMatchingSizeInStock) return false;
      }

      // Colors
      if (filters.colors.length > 0) {
        const hasMatchingColor = product.colors.some((c) =>
          filters.colors.some((fc) => c.name.toLowerCase().includes(fc.toLowerCase()) || fc.toLowerCase().includes(c.name.toLowerCase()))
        );
        if (!hasMatchingColor) return false;
      }

      // Price Range
      if (product.price < filters.priceRange[0] || product.price > filters.priceRange[1]) {
        return false;
      }

      // Fit Type
      if (filters.fitType && product.fitType !== filters.fitType) {
        return false;
      }

      // In stock
      if (filters.inStockOnly && !product.inStock) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'price-asc') return a.price - b.price;
      if (filters.sortBy === 'price-desc') return b.price - a.price;
      if (filters.sortBy === 'rating') return b.rating - a.rating;
      if (filters.sortBy === 'bestselling') return b.reviewCount - a.reviewCount;
      if (filters.sortBy === 'newest') return (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0);
      // Default: featured (bestseller and trending first)
      const aScore = (a.isBestseller ? 2 : 0) + (a.isTrending ? 1 : 0);
      const bScore = (b.isBestseller ? 2 : 0) + (b.isTrending ? 1 : 0);
      return bScore - aScore;
    });
  }, [filters, products]);

  // Wishlist products
  const wishlistProducts = useMemo(() => {
    return products.filter((p) => wishlistIds.includes(p.id));
  }, [wishlistIds, products]);

  // Cart totals for checkout
  const rawSubtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const totalItemCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const bundleDiscount = totalItemCount >= 2 ? Math.round(rawSubtotal * 0.1) : 0;
  let couponDiscount = 0;
  if (appliedCoupon && VALID_COUPONS[appliedCoupon]) {
    const coup = VALID_COUPONS[appliedCoupon];
    if (coup.discountPercent) {
      couponDiscount = Math.round((rawSubtotal - bundleDiscount) * (coup.discountPercent / 100));
    } else if (coup.flatDiscount) {
      couponDiscount = coup.flatDiscount;
    }
  }
  const isFreeShippingUnlocked = rawSubtotal >= 999 || appliedCoupon === 'FREESHIP';
  const shippingFee = cartItems.length === 0 ? 0 : isFreeShippingUnlocked ? 0 : 79;
  const giftWrapFee = giftWrap ? 49 : 0;
  const finalTotal = Math.max(0, rawSubtotal - bundleDiscount - couponDiscount + shippingFee + giftWrapFee);

  const handleOrderSuccess = async (order: OrderConfirmation) => {
    try {
      await saveOrderToFirebase(order);
      showToast('Order confirmed & saved to database!');
    } catch (err) {
      console.error('Error saving order to Firebase:', err);
    }
    setCartItems([]);
    setAppliedCoupon(null);
    setGiftWrap(false);
  };

  // Determine grid column styling for desktop and mobile
  const gridClass =
    gridCols === 1
      ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
      : gridCols === 2
      ? 'grid-cols-2 md:grid-cols-2 lg:grid-cols-3'
      : gridCols === 4
      ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4'
      : 'grid-cols-2 sm:grid-cols-2 md:grid-cols-3';

  const activeFilterCount =
    (filters.subCategory && filters.subCategory !== 'All Tops' ? 1 : 0) +
    filters.sizes.length +
    filters.colors.length +
    (filters.fitType ? 1 : 0) +
    (filters.inStockOnly ? 1 : 0) +
    (filters.priceRange[0] > 600 || filters.priceRange[1] < 1500 ? 1 : 0) +
    (filters.searchQuery ? 1 : 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-stone-900">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 md:bottom-6 right-4 sm:right-6 z-50 bg-stone-950/95 backdrop-blur-md text-white px-4 py-2.5 rounded-xl shadow-2xl text-xs font-semibold flex items-center gap-2 border border-stone-800 animate-slideUp">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <Header
        cartItems={cartItems}
        wishlistIds={wishlistIds}
        onOpenCart={() => setCartDrawerOpen(true)}
        onOpenWishlist={() => setWishlistDrawerOpen(true)}
        onSelectCategory={(cat) => setFilters((prev) => ({ ...prev, subCategory: cat === 'All Tops' ? '' : cat }))}
        activeCategory={filters.subCategory || 'All Tops'}
        onSearch={(query) => setFilters((prev) => ({ ...prev, searchQuery: query }))}
        searchQuery={filters.searchQuery}
        products={PRODUCTS}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      {/* Main Campaign Hero Banner */}
      {!filters.searchQuery && (
        <HeroBanner
          onSelectCategory={(cat) => setFilters((prev) => ({ ...prev, subCategory: cat }))}
          productCount={PRODUCTS.length}
        />
      )}

      {/* Main Catalog View Container */}
      <main className="flex-1 max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 sm:py-8 w-full pb-28 md:pb-12">
        {/* Collection Title & Sub-kicker */}
        <div className="mb-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-stone-500 uppercase tracking-widest">
            <span>Women's Fast Fashion</span>
            <span aria-hidden="true">·</span>
            <span>Orgavo India</span>
            <span aria-hidden="true">·</span>
            <span className="text-stone-900 font-bold">{filters.subCategory || 'All Tops'}</span>
          </div>

          <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-stone-950 mt-1">
            {filters.subCategory ? `${filters.subCategory} Collection` : 'Trending Tops & Corsets'}
          </h2>
          <p className="text-xs sm:text-sm text-stone-500 mt-1">
            Discover {filteredProducts.length} signature styles designed for contemporary streetwear, dates & weekend brunches.
          </p>
        </div>

        {/* Filter and Sorting Control Bar */}
        <FilterBar
          filters={filters}
          onUpdateFilters={(newF) => setFilters((prev) => ({ ...prev, ...newF }))}
          onOpenFilterDrawer={() => setFilterDrawerOpen(true)}
          totalFilteredCount={filteredProducts.length}
          totalCount={PRODUCTS.length}
          gridCols={gridCols}
          onChangeGridCols={setGridCols}
          onResetFilters={handleResetFilters}
        />

        {/* Product Cards Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center bg-white rounded-2xl border border-stone-200 p-8 space-y-4 my-6">
            <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center mx-auto text-stone-400">
              <ShoppingBag className="w-8 h-8" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-stone-900">
                No matching styles found
              </h3>
              <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                We couldn't find any tops matching your current filters. Try relaxing your size, color, or price range.
              </p>
            </div>
            <button
              onClick={handleResetFilters}
              className="px-5 py-2.5 bg-stone-950 text-white text-xs font-bold rounded-xl hover:bg-stone-800 transition-colors cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className={`grid ${gridClass} gap-4 sm:gap-6 my-6`}>
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                isWishlisted={wishlistIds.includes(product.id)}
                onToggleWishlist={handleToggleWishlist}
                onSelectProduct={(p) => setSelectedProduct(p)}
                onQuickAddToCart={handleQuickAddToCart}
              />
            ))}
          </div>
        )}

        {/* Curated Lookbook Section */}
        <LookbookSection
          products={PRODUCTS}
          onSelectProduct={(p) => setSelectedProduct(p)}
        />

        {/* Trust Badges Bar */}
        <TrustBanner />
      </main>

      {/* Slide-over Filter Drawer */}
      <FilterDrawer
        isOpen={filterDrawerOpen}
        onClose={() => setFilterDrawerOpen(false)}
        filters={filters}
        onUpdateFilters={(newF) => setFilters((prev) => ({ ...prev, ...newF }))}
        onResetFilters={handleResetFilters}
        totalFilteredCount={filteredProducts.length}
      />

      {/* Product Detail Modal (PDP) */}
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          isWishlisted={wishlistIds.includes(selectedProduct.id)}
          onToggleWishlist={handleToggleWishlist}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
        />
      )}

      {/* Shopping Bag Drawer */}
      <CartDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={() => {
          setCartDrawerOpen(false);
          setCheckoutModalOpen(true);
        }}
        appliedCoupon={appliedCoupon}
        onApplyCoupon={handleApplyCoupon}
        onRemoveCoupon={() => setAppliedCoupon(null)}
        giftWrap={giftWrap}
        onToggleGiftWrap={() => setGiftWrap(!giftWrap)}
      />

      {/* Saved Wishlist Drawer */}
      <WishlistDrawer
        isOpen={wishlistDrawerOpen}
        onClose={() => setWishlistDrawerOpen(false)}
        wishlistProducts={wishlistProducts}
        onRemoveFromWishlist={handleToggleWishlist}
        onSelectProduct={(p) => setSelectedProduct(p)}
        onAddToCart={(p) => handleQuickAddToCart(p, p.sizes[0] || 'S')}
      />

      {/* Express Checkout Modal */}
      <CheckoutModal
        isOpen={checkoutModalOpen}
        onClose={() => setCheckoutModalOpen(false)}
        items={cartItems}
        subtotal={rawSubtotal}
        discount={bundleDiscount + couponDiscount}
        shippingFee={shippingFee}
        total={finalTotal}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Mobile Fixed Bottom Navigation Bar - Pattern 1 */}
      <MobileBottomNav
        activeTab="home"
        onOpenFilter={() => setFilterDrawerOpen(true)}
        onOpenWishlist={() => setWishlistDrawerOpen(true)}
        onOpenCart={() => setCartDrawerOpen(true)}
        onScrollToTop={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        cartItems={cartItems}
        wishlistIds={wishlistIds}
        activeFilterCount={activeFilterCount}
      />

      {/* Footer */}
      <Footer onOpenAdmin={() => setAdminOpen(true)} />

      {/* Admin Panel Modal */}
      <AdminPanel
        isOpen={adminOpen}
        onClose={() => setAdminOpen(false)}
        products={products}
      />
    </div>
  );
}
