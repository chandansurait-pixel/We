export interface Review {
  id: string;
  author: string;
  location: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  verifiedPurchase: boolean;
  sizePurchased: string;
  helpfulCount: number;
}

export type Size = 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL';

export interface ProductColor {
  name: string;
  hex: string;
  imageIndex: number;
}

export interface Product {
  id: string;
  name: string;
  handle: string;
  category: string;
  subCategory: 'Corsets' | 'Baby Tees' | 'Knitwear' | 'Blouses' | 'Halters & Camis' | 'Party Tops';
  price: number;
  originalPrice: number;
  discountPercent: number;
  colors: ProductColor[];
  sizes: Size[];
  sizeStock: Record<Size, number>;
  inStock: boolean;
  isBestseller?: boolean;
  isTrending?: boolean;
  isNewArrival?: boolean;
  rating: number;
  reviewCount: number;
  images: string[];
  description: string;
  fabricDetails: string[];
  fitType: 'Fitted' | 'Regular' | 'Relaxed' | 'Cropped';
  modelInfo: string;
  styleTips: string;
  reviews: Review[];
}

export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  selectedSize: Size;
  selectedColor: ProductColor;
  quantity: number;
}

export interface FilterState {
  searchQuery: string;
  subCategory: string;
  sizes: Size[];
  colors: string[];
  priceRange: [number, number];
  fitType: string;
  sortBy: 'featured' | 'bestselling' | 'price-asc' | 'price-desc' | 'rating' | 'newest';
  inStockOnly: boolean;
}

export interface ShippingAddress {
  fullName: string;
  phone: string;
  email: string;
  pincode: string;
  city: string;
  state: string;
  street: string;
  paymentMethod: 'upi' | 'card' | 'cod' | 'netbanking';
  upiApp?: string;
}

export interface OrderConfirmation {
  orderId: string;
  createdAt: string;
  items: CartItem[];
  shippingAddress: ShippingAddress;
  subtotal: number;
  discount: number;
  shippingFee: number;
  total: number;
  paymentMethod: string;
  estimatedDelivery: string;
}
