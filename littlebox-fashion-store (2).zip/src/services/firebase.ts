import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getDatabase, 
  ref, 
  onValue, 
  set, 
  push, 
  remove, 
  update, 
  get, 
  Database 
} from 'firebase/database';
import { Product, OrderConfirmation } from '../types';

export const firebaseConfig = {
  apiKey: "AIzaSyAICY7RDJKsvb_CsfdpEYpFxXNBaOlfltQ",
  authDomain: "bbbb-1290c.firebaseapp.com",
  databaseURL: "https://bbbb-1290c-default-rtdb.firebaseio.com",
  projectId: "bbbb-1290c",
  storageBucket: "bbbb-1290c.firebasestorage.app",
  messagingSenderId: "627420383102",
  appId: "1:627420383102:web:06ebe9acd94b37751f152f"
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const db: Database = getDatabase(app);

// Reference pointers
export const productsRef = ref(db, 'products');
export const ordersRef = ref(db, 'orders');
export const whatsappNumberRef = ref(db, 'config/whatsappNumber');
export const whatsappMessageRef = ref(db, 'config/whatsappMessage');

/**
 * Initialize products in Firebase if not already present
 */
export async function initializeProductsIfNeeded(initialProducts: Product[]) {
  try {
    const snapshot = await get(productsRef);
    if (!snapshot.exists() || !snapshot.val()) {
      const productsMap: Record<string, Product> = {};
      initialProducts.forEach((p) => {
        productsMap[p.id] = p;
      });
      await set(productsRef, productsMap);
      console.log('Initial products seeded to Firebase successfully');
    }
  } catch (err) {
    console.error('Error seeding products to Firebase:', err);
  }
}

/**
 * Real-time listener for products
 */
export function subscribeToProducts(callback: (products: Product[]) => void) {
  return onValue(productsRef, (snapshot) => {
    const data = snapshot.val();
    if (data) {
      if (Array.isArray(data)) {
        callback(data.filter(Boolean));
      } else {
        callback(Object.values(data));
      }
    } else {
      callback([]);
    }
  }, (err) => {
    console.error('Firebase onValue products error:', err);
  });
}

/**
 * Save or update single product
 */
export async function saveProductToFirebase(product: Product) {
  const prodRef = ref(db, `products/${product.id}`);
  await set(prodRef, product);
}

/**
 * Delete product
 */
export async function deleteProductFromFirebase(productId: string) {
  const prodRef = ref(db, `products/${productId}`);
  await remove(prodRef);
}

/**
 * Update stock or price quick patch
 */
export async function updateProductFieldInFirebase(productId: string, updates: Partial<Product>) {
  const prodRef = ref(db, `products/${productId}`);
  await update(prodRef, updates);
}

/**
 * Push new order from customer checkout
 */
export async function saveOrderToFirebase(order: OrderConfirmation) {
  const orderRef = ref(db, `orders/${order.orderId}`);
  await set(orderRef, {
    ...order,
    status: 'Pending',
    updatedAt: new Date().toISOString(),
  });
}

/**
 * Real-time listener for orders
 */
export function subscribeToOrders(callback: (orders: any[]) => void) {
  return onValue(ordersRef, (snapshot) => {
    const data = snapshot.val();
    if (data) {
      const list = Object.values(data);
      // Sort newest first
      list.sort((a: any, b: any) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      callback(list);
    } else {
      callback([]);
    }
  });
}

/**
 * Update order status (Pending, Confirmed, Shipped, Delivered, Cancelled)
 */
export async function updateOrderStatusInFirebase(orderId: string, status: string) {
  const orderRef = ref(db, `orders/${orderId}`);
  await update(orderRef, { status, updatedAt: new Date().toISOString() });
}

/**
 * Real-time listener for WhatsApp config
 */
export function subscribeToWhatsAppConfig(callback: (data: { number: string; message: string }) => void) {
  let num = '917545936515';
  let msg = 'I want new id with 10% welcome bonus';

  const unsub1 = onValue(whatsappNumberRef, (snap) => {
    if (snap.exists() && snap.val()) num = snap.val();
    callback({ number: num, message: msg });
  });

  const unsub2 = onValue(whatsappMessageRef, (snap) => {
    if (snap.exists() && snap.val()) msg = snap.val();
    callback({ number: num, message: msg });
  });

  return () => {
    unsub1();
    unsub2();
  };
}

export async function saveWhatsAppConfigToFirebase(number: string, message: string) {
  await set(whatsappNumberRef, number);
  await set(whatsappMessageRef, message);
}
