import React from 'react';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { Product } from '../types';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistProducts: Product[];
  onRemoveFromWishlist: (productId: string) => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistProducts,
  onRemoveFromWishlist,
  onSelectProduct,
  onAddToCart,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex items-end sm:items-stretch sm:justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Drawer */}
      <div className="relative w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-none h-[88vh] sm:h-full shadow-2xl flex flex-col z-10 animate-sheet-up">
        {/* Mobile Grab Handle */}
        <div className="sm:hidden w-full pt-3 pb-1 flex justify-center bg-white shrink-0">
          <div className="w-12 h-1.5 bg-stone-300 rounded-full" />
        </div>

        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-rose-500 fill-current animate-heart-pop" />
            <h2 className="text-base font-bold text-stone-900">Saved Wishlist</h2>
            <span className="text-xs bg-stone-100 text-stone-700 font-semibold px-2 py-0.5 rounded-full">
              {wishlistProducts.length}
            </span>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center text-stone-500 hover:text-stone-900 rounded-full hover:bg-stone-100 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wishlist Items */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 divide-y divide-stone-100">
          {wishlistProducts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 bg-rose-50 text-rose-400 rounded-full flex items-center justify-center">
                <Heart className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-base font-bold text-stone-900">No saved items yet</h3>
                <p className="text-xs text-stone-500 mt-1 max-w-xs">
                  Tap the heart icon on any top to save it here for later or price drops.
                </p>
              </div>
              <button
                onClick={onClose}
                className="px-5 py-2.5 bg-stone-900 text-white text-xs font-bold rounded-xl hover:bg-stone-800 transition-colors"
              >
                Browse Tops
              </button>
            </div>
          ) : (
            wishlistProducts.map((prod) => (
              <div key={prod.id} className="py-4 first:pt-0 last:pb-0 flex gap-3 sm:gap-4">
                <div
                  onClick={() => {
                    onSelectProduct(prod);
                    onClose();
                  }}
                  className="w-20 h-24 rounded-lg overflow-hidden bg-stone-100 shrink-0 cursor-pointer"
                >
                  <img
                    src={prod.images[0]}
                    alt={prod.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex-1 flex flex-col justify-between min-w-0">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h4
                        onClick={() => {
                          onSelectProduct(prod);
                          onClose();
                        }}
                        className="text-xs font-semibold text-stone-900 line-clamp-1 cursor-pointer hover:text-stone-700"
                      >
                        {prod.name}
                      </h4>
                      <button
                        onClick={() => onRemoveFromWishlist(prod.id)}
                        className="text-stone-400 hover:text-rose-600 transition-colors p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <p className="text-[11px] text-stone-500 mt-0.5">{prod.subCategory}</p>

                    <div className="mt-1 flex items-baseline gap-2">
                      <span className="text-xs font-bold text-stone-900 tabular-nums">
                        ₹{prod.price}
                      </span>
                      <span className="text-[11px] text-stone-400 line-through tabular-nums">
                        ₹{prod.originalPrice}
                      </span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={() => {
                        onAddToCart(prod);
                        onRemoveFromWishlist(prod.id);
                      }}
                      className="w-full py-1.5 px-3 bg-stone-900 hover:bg-stone-800 text-white text-[11px] font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <ShoppingBag className="w-3 h-3" />
                      <span>Move to Bag</span>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
