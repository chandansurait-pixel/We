import React from 'react';
import { HERO_BANNER_IMAGE } from '../data/products';
import { Sparkles, ArrowRight, ShieldCheck, RefreshCw, Zap } from 'lucide-react';

interface HeroBannerProps {
  onSelectCategory: (category: string) => void;
  productCount: number;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onSelectCategory, productCount }) => {
  return (
    <section className="relative overflow-hidden bg-stone-950 text-white">
      {/* Background Hero Image with measured contrast scrim */}
      <div className="absolute inset-0">
        <img
          src={HERO_BANNER_IMAGE}
          alt="Orgavo India Tops Collection"
          className="w-full h-full object-cover object-center opacity-65 scale-102 transition-transform duration-700 hover:scale-105"
          referrerPolicy="no-referrer"
          decoding="async"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-stone-950/90 via-stone-950/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-stone-950/40" />
      </div>

      {/* Hero Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-24 lg:py-28 flex flex-col justify-center min-h-[320px] sm:min-h-[460px]">
        <div className="max-w-2xl">
          {/* Subtle Tagline */}
          <div className="flex items-center gap-2 mb-2 sm:mb-3">
            <span className="text-amber-400 uppercase tracking-widest text-[10px] sm:text-[11px] font-bold">
              The Viral Drop • Season 2026
            </span>
            <span className="text-stone-400">·</span>
            <span className="text-stone-300 text-xs">{productCount} Styles</span>
          </div>

          {/* Main Title */}
          <h1 className="font-display text-2xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.15] sm:leading-[1.1] mb-3 sm:mb-4 text-balance">
            THE TOPS <br className="hidden sm:inline" />
            <span className="italic font-normal font-serif text-amber-200">COLLECTION</span>
          </h1>

          {/* Description */}
          <p className="text-xs sm:text-base text-stone-200/90 leading-relaxed mb-4 sm:mb-6 font-light max-w-xl">
            From sculpted lace-up corsets and 90s vintage baby tees to lightweight open-knit halters starting at ₹649.
          </p>

          {/* Quick Jump Category Buttons */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar pt-1">
            <button
              onClick={() => onSelectCategory('Corsets')}
              className="bg-white text-stone-950 px-3.5 py-1.5 sm:px-4 sm:py-2 text-xs font-bold rounded-full hover:bg-stone-100 active:scale-95 transition-all flex items-center gap-1.5 shadow-sm cursor-pointer whitespace-nowrap shrink-0"
            >
              Shop Corsets
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onSelectCategory('Baby Tees')}
              className="bg-stone-900/80 backdrop-blur-xs text-white border border-stone-700/80 px-3 py-1.5 sm:px-4 sm:py-2 text-xs font-semibold rounded-full hover:bg-stone-800 active:scale-95 transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              Baby Tees
            </button>
            <button
              onClick={() => onSelectCategory('Knitwear')}
              className="bg-stone-900/80 backdrop-blur-xs text-white border border-stone-700/80 px-3 py-1.5 sm:px-4 sm:py-2 text-xs font-semibold rounded-full hover:bg-stone-800 active:scale-95 transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              Knitwear
            </button>
            <button
              onClick={() => onSelectCategory('Blouses')}
              className="bg-stone-900/80 backdrop-blur-xs text-white border border-stone-700/80 px-3 py-1.5 sm:px-4 sm:py-2 text-xs font-semibold rounded-full hover:bg-stone-800 active:scale-95 transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              Romantic Blouses
            </button>
          </div>
        </div>
      </div>

      {/* Feature Micro-Badges Bar */}
      <div className="relative border-t border-stone-800/80 bg-stone-950/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="flex items-center justify-center gap-2 text-xs text-stone-300">
            <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>Trending Y2K & Korean Cuts</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-xs text-stone-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Inclusive Sizing XS to XXL</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-xs text-stone-300">
            <RefreshCw className="w-3.5 h-3.5 text-blue-400 shrink-0" />
            <span>7-Day Doorstep Exchange</span>
          </div>
          <div className="flex items-center justify-center gap-2 text-xs text-stone-300">
            <Sparkles className="w-3.5 h-3.5 text-pink-400 shrink-0" />
            <span>Cash on Delivery Available</span>
          </div>
        </div>
      </div>
    </section>
  );
};
