import React, { useState } from 'react';
import { Heart, Star, ShoppingBag, Check, ChevronDown, ChevronUp } from 'lucide-react';
import { Product, Size } from '../types';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
  onSelectProduct: (product: Product) => void;
  onQuickAddToCart: (product: Product, size: Size) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onSelectProduct,
  onQuickAddToCart,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [selectedColorIdx, setSelectedColorIdx] = useState(0);
  const [justAddedSize, setJustAddedSize] = useState<string | null>(null);
  const [mobileSizeOpen, setMobileSizeOpen] = useState(false);

  const displayImage = product.images[selectedColorIdx] || product.images[0];
  const secondaryImage = product.images[1] || product.images[0];

  const handleQuickAdd = (e: React.MouseEvent, size: Size) => {
    e.stopPropagation();
    onQuickAddToCart(product, size);
    setJustAddedSize(size);
    setTimeout(() => {
      setJustAddedSize(null);
      setMobileSizeOpen(false);
    }, 900);
  };

  return (
    <div
      className="group relative flex flex-col cursor-pointer bg-white rounded-2xl overflow-hidden border border-stone-200/90 hover:border-stone-400 hover:shadow-lg transition-all duration-300 active:scale-[0.99]"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => onSelectProduct(product)}
    >
      {/* Product Image Frame */}
      <div className="relative aspect-[3/4] w-full overflow-hidden bg-stone-100">
        {/* Primary Image */}
        <img
          src={displayImage}
          alt={product.name}
          className={`h-full w-full object-cover object-center transition-all duration-500 ${
            isHovered && product.images.length > 1 ? 'opacity-0 scale-105' : 'opacity-100 scale-100'
          }`}
          referrerPolicy="no-referrer"
          loading="lazy"
          decoding="async"
        />

        {/* Secondary Image on Hover */}
        {product.images.length > 1 && (
          <img
            src={secondaryImage}
            alt={`${product.name} alternate view`}
            className={`absolute inset-0 h-full w-full object-cover object-center transition-all duration-500 ${
              isHovered ? 'opacity-100 scale-105' : 'opacity-0 scale-100'
            }`}
            referrerPolicy="no-referrer"
            loading="lazy"
            decoding="async"
          />
        )}

        {/* Badges Overlay */}
        <div className="absolute top-2 left-2 sm:top-2.5 sm:left-2.5 flex flex-col gap-1 z-10 pointer-events-none">
          {product.isBestseller && (
            <span className="bg-stone-900/90 backdrop-blur-xs text-white text-[9px] sm:text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded shadow-xs">
              Bestseller
            </span>
          )}
          {product.isTrending && !product.isBestseller && (
            <span className="bg-amber-400 text-stone-950 text-[9px] sm:text-[10px] font-extrabold tracking-wider uppercase px-2 py-0.5 rounded shadow-xs">
              Trending
            </span>
          )}
          {product.discountPercent > 0 && (
            <span className="bg-rose-50 text-rose-700 border border-rose-200 text-[9px] sm:text-[10px] font-bold px-1.5 py-0.5 rounded">
              {product.discountPercent}% OFF
            </span>
          )}
        </div>

        {/* Wishlist Button - Touch optimized min-w-[44px] */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product.id);
          }}
          aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          className={`absolute top-1.5 right-1.5 sm:top-2.5 sm:right-2.5 min-w-[40px] min-h-[40px] rounded-full flex items-center justify-center transition-all z-10 cursor-pointer active:scale-125 shadow-xs ${
            isWishlisted
              ? 'bg-rose-50 text-rose-600 shadow-sm animate-heart-pop'
              : 'bg-white/85 backdrop-blur-md text-stone-700 hover:text-rose-600 hover:bg-white'
          }`}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Desktop Quick Size Bar: Slides up on desktop hover */}
        <div
          className={`absolute bottom-0 inset-x-0 bg-stone-950/90 backdrop-blur-md p-2 transition-transform duration-300 z-10 ${
            isHovered ? 'translate-y-0' : 'translate-y-full'
          } hidden sm:block`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between text-[11px] text-stone-300 mb-1.5 px-1">
            <span className="font-semibold uppercase tracking-wider text-[10px]">Quick Add Size</span>
            <span className="text-[10px] text-stone-400">Tap to bag</span>
          </div>
          <div className="flex items-center justify-center gap-1">
            {product.sizes.map((size) => {
              const inStock = (product.sizeStock[size] ?? 0) > 0;
              const isAdded = justAddedSize === size;
              return (
                <button
                  key={size}
                  disabled={!inStock}
                  onClick={(e) => handleQuickAdd(e, size)}
                  className={`flex-1 py-1 text-center text-xs font-bold rounded transition-all active:scale-95 ${
                    isAdded
                      ? 'bg-emerald-500 text-white'
                      : inStock
                      ? 'bg-stone-800 text-stone-100 hover:bg-white hover:text-stone-950 cursor-pointer'
                      : 'bg-stone-900/50 text-stone-600 cursor-not-allowed line-through'
                  }`}
                  title={inStock ? `Add size ${size}` : 'Out of stock'}
                >
                  {isAdded ? <Check className="w-3.5 h-3.5 mx-auto" /> : size}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Product Card Details */}
      <div className="p-3 sm:p-3.5 flex flex-col flex-1 justify-between bg-white">
        <div>
          {/* Metadata: Category & Rating */}
          <div className="flex items-center justify-between text-[10px] sm:text-[11px] text-stone-500 mb-1">
            <span className="truncate">{product.subCategory}</span>
            <div className="flex items-center gap-1 text-stone-800 font-semibold text-[10px] sm:text-[11px]">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400 shrink-0" />
              <span>{product.rating}</span>
            </div>
          </div>

          {/* Product Title */}
          <h3 className="text-xs sm:text-[13px] font-semibold text-stone-900 line-clamp-1 group-hover:text-stone-700 transition-colors">
            {product.name}
          </h3>
        </div>

        {/* Price & Color Variants */}
        <div className="pt-2 mt-1.5 border-t border-stone-100 flex items-center justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="font-bold text-sm sm:text-base text-stone-950 tabular-nums">
              ₹{product.price}
            </span>
            <span className="text-[11px] sm:text-xs text-stone-400 line-through tabular-nums">
              ₹{product.originalPrice}
            </span>
          </div>

          {/* Color preview dots */}
          {product.colors.length > 0 && (
            <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
              {product.colors.slice(0, 3).map((col, idx) => (
                <button
                  key={col.name}
                  onClick={() => setSelectedColorIdx(idx)}
                  title={col.name}
                  className={`w-3 h-3 sm:w-3.5 sm:h-3.5 rounded-full border transition-transform ${
                    selectedColorIdx === idx ? 'scale-125 ring-1 ring-stone-900 ring-offset-1' : 'border-stone-300'
                  }`}
                  style={{ backgroundColor: col.hex }}
                />
              ))}
            </div>
          )}
        </div>

        {/* Mobile Quick Add Selector / Dropdown */}
        <div className="sm:hidden mt-2 pt-2 border-t border-stone-100" onClick={(e) => e.stopPropagation()}>
          {!mobileSizeOpen ? (
            <button
              onClick={() => setMobileSizeOpen(true)}
              className="w-full py-2 bg-stone-100 hover:bg-stone-200 active:scale-95 text-stone-900 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1.5 transition-all shadow-xs"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Quick Add Size</span>
              <ChevronDown className="w-3 h-3 text-stone-500" />
            </button>
          ) : (
            <div className="space-y-1.5 animate-fadeIn">
              <div className="flex items-center justify-between text-[10px] text-stone-500 px-0.5">
                <span>Select Size:</span>
                <button
                  onClick={() => setMobileSizeOpen(false)}
                  className="text-stone-400 hover:text-stone-700"
                >
                  <ChevronUp className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex gap-1 overflow-x-auto pb-0.5 no-scrollbar">
                {product.sizes.map((size) => {
                  const inStock = (product.sizeStock[size] ?? 0) > 0;
                  const isAdded = justAddedSize === size;
                  return (
                    <button
                      key={size}
                      disabled={!inStock}
                      onClick={(e) => handleQuickAdd(e, size)}
                      className={`flex-1 min-h-[32px] py-1 text-center text-[10px] font-bold rounded-md border transition-all active:scale-90 ${
                        isAdded
                          ? 'bg-emerald-500 border-emerald-500 text-white'
                          : inStock
                          ? 'bg-white border-stone-300 text-stone-900 active:bg-stone-900 active:text-white'
                          : 'bg-stone-100 border-stone-200 text-stone-300 line-through'
                      }`}
                    >
                      {isAdded ? <Check className="w-3 h-3 mx-auto" /> : size}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
