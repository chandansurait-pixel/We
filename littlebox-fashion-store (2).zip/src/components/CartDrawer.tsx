import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  ArrowRight, 
  Truck, 
  Sparkles, 
  Tag, 
  Gift, 
  ShieldCheck,
  Check
} from 'lucide-react';
import { CartItem } from '../types';
import { VALID_COUPONS } from '../data/products';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onCheckout: () => void;
  appliedCoupon: string | null;
  onApplyCoupon: (code: string) => boolean;
  onRemoveCoupon: () => void;
  giftWrap: boolean;
  onToggleGiftWrap: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  appliedCoupon,
  onApplyCoupon,
  onRemoveCoupon,
  giftWrap,
  onToggleGiftWrap,
}) => {
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Pricing calculations
  const rawSubtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const totalItemCount = items.reduce((acc, item) => acc + item.quantity, 0);

  // Automatic "BUY 2 GET 10% OFF" promotion if 2 or more tops
  const hasBundlePromo = totalItemCount >= 2;
  const bundleDiscount = hasBundlePromo ? Math.round(rawSubtotal * 0.1) : 0;

  // Applied Coupon discount
  let couponDiscount = 0;
  if (appliedCoupon && VALID_COUPONS[appliedCoupon]) {
    const coup = VALID_COUPONS[appliedCoupon];
    if (coup.discountPercent) {
      couponDiscount = Math.round((rawSubtotal - bundleDiscount) * (coup.discountPercent / 100));
    } else if (coup.flatDiscount) {
      couponDiscount = coup.flatDiscount;
    }
  }

  // Free shipping threshold is ₹999
  const FREE_SHIPPING_THRESHOLD = 999;
  const amountNeededForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - rawSubtotal);
  const isFreeShippingUnlocked = amountNeededForFreeShipping === 0 || appliedCoupon === 'FREESHIP';
  const shippingFee = items.length === 0 ? 0 : isFreeShippingUnlocked ? 0 : 79;
  const giftWrapFee = giftWrap ? 49 : 0;

  const finalTotal = Math.max(0, rawSubtotal - bundleDiscount - couponDiscount + shippingFee + giftWrapFee);
  const totalSavings = bundleDiscount + couponDiscount + (items.reduce((acc, item) => acc + (item.product.originalPrice - item.product.price) * item.quantity, 0));

  const handleApplyCouponCode = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    const code = couponInput.trim().toUpperCase();
    if (!code) return;

    const success = onApplyCoupon(code);
    if (success) {
      setCouponInput('');
    } else {
      setCouponError('Invalid coupon code or minimum spend requirement not met.');
    }
  };

  const progressPercent = Math.min(100, Math.round((rawSubtotal / FREE_SHIPPING_THRESHOLD) * 100));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex items-end sm:items-stretch sm:justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Slide-over / Bottom Sheet Bag Panel */}
      <div className="relative w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-none h-[92vh] sm:h-full shadow-2xl flex flex-col z-10 animate-sheet-up">
        {/* Mobile Grab Handle */}
        <div className="sm:hidden w-full pt-3 pb-1 flex justify-center bg-white shrink-0">
          <div className="w-12 h-1.5 bg-stone-300 rounded-full" />
        </div>

        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-stone-900" />
            <h2 className="text-base font-bold text-stone-900">Your Shopping Bag</h2>
            <span className="text-xs bg-stone-100 text-stone-700 font-semibold px-2 py-0.5 rounded-full">
              {totalItemCount}
            </span>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center text-stone-500 hover:text-stone-900 rounded-full hover:bg-stone-100 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Dynamic Progress Bar */}
        <div className="p-3.5 bg-stone-50 border-b border-stone-200">
          <div className="flex items-center justify-between text-xs mb-1.5 font-medium">
            {isFreeShippingUnlocked ? (
              <span className="text-emerald-700 font-bold flex items-center gap-1">
                <Truck className="w-3.5 h-3.5" />
                You've unlocked FREE Express Shipping across India!
              </span>
            ) : (
              <span className="text-stone-700">
                Add <strong className="text-stone-950 font-bold">₹{amountNeededForFreeShipping}</strong> more to unlock <span className="text-amber-700 font-bold">FREE Shipping</span>
              </span>
            )}
            <span className="text-[11px] text-stone-500 font-bold">{progressPercent}%</span>
          </div>
          <div className="w-full h-1.5 bg-stone-200 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                isFreeShippingUnlocked ? 'bg-emerald-500' : 'bg-stone-900'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Items Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 divide-y divide-stone-100">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center text-stone-400">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-base font-bold text-stone-900">Your bag is empty</h3>
                <p className="text-xs text-stone-500 mt-1 max-w-xs">
                  Looks like you haven't added any viral tops yet. Explore our curated drop!
                </p>
              </div>
              <button
                onClick={onClose}
                className="px-5 py-2.5 bg-stone-900 text-white text-xs font-bold rounded-xl hover:bg-stone-800 transition-colors"
              >
                Start Shopping
              </button>
            </div>
          ) : (
            items.map((item) => (
              <div key={item.id} className="py-4 first:pt-0 last:pb-0 flex gap-3 sm:gap-4">
                {/* Item Thumbnail */}
                <div className="w-20 h-24 rounded-lg overflow-hidden bg-stone-100 shrink-0">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Item Details */}
                <div className="flex-1 flex flex-col justify-between min-w-0">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs font-semibold text-stone-900 line-clamp-1">
                        {item.product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.id)}
                        className="text-stone-400 hover:text-rose-600 transition-colors p-1"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-stone-500 mt-1">
                      <span>Size: <strong className="text-stone-800">{item.selectedSize}</strong></span>
                      <span>·</span>
                      <span className="flex items-center gap-1">
                        <span
                          className="w-2.5 h-2.5 rounded-full border border-stone-300"
                          style={{ backgroundColor: item.selectedColor.hex }}
                        />
                        {item.selectedColor.name}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    {/* Quantity Selector */}
                    <div className="flex items-center border border-stone-200 rounded-lg">
                      <button
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="px-2 py-0.5 text-stone-500 hover:text-stone-900 text-xs font-semibold"
                      >
                        -
                      </button>
                      <span className="px-2 text-xs font-bold text-stone-900 tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="px-2 py-0.5 text-stone-500 hover:text-stone-900 text-xs font-semibold"
                      >
                        +
                      </button>
                    </div>

                    {/* Price */}
                    <div className="text-right">
                      <span className="text-xs font-bold text-stone-900 tabular-nums">
                        ₹{item.product.price * item.quantity}
                      </span>
                      <span className="block text-[10px] text-stone-400 line-through tabular-nums">
                        ₹{item.product.originalPrice * item.quantity}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {items.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-stone-200 bg-stone-50 space-y-3.5">
            {/* Coupon Code Section */}
            <div>
              {appliedCoupon ? (
                <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs">
                  <div className="flex items-center gap-1.5 text-emerald-800 font-semibold">
                    <Tag className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Coupon <strong>{appliedCoupon}</strong> applied!</span>
                  </div>
                  <button
                    onClick={onRemoveCoupon}
                    className="text-emerald-700 hover:text-emerald-950 font-bold underline text-[11px]"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCouponCode} className="space-y-1.5">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => {
                        setCouponInput(e.target.value);
                        setCouponError(null);
                      }}
                      placeholder="Enter promo code (e.g. TRENDY10)"
                      className="flex-1 bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs text-stone-900 uppercase focus:outline-none focus:ring-1 focus:ring-stone-900"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-1.5 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-stone-800 transition-colors"
                    >
                      Apply
                    </button>
                  </div>
                  {couponError && <p className="text-[11px] text-rose-600">{couponError}</p>}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => onApplyCoupon('TRENDY10')}
                      className="text-[10px] bg-white border border-stone-200 text-stone-700 hover:border-stone-900 px-2 py-0.5 rounded cursor-pointer"
                    >
                      🏷️ TRENDY10 (10% OFF)
                    </button>
                    <button
                      type="button"
                      onClick={() => onApplyCoupon('FIRSTBUY')}
                      className="text-[10px] bg-white border border-stone-200 text-stone-700 hover:border-stone-900 px-2 py-0.5 rounded cursor-pointer"
                    >
                      ✨ FIRSTBUY (₹150 OFF)
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* Gift Wrap Add-on */}
            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-stone-700 font-medium">
                <input
                  type="checkbox"
                  checked={giftWrap}
                  onChange={onToggleGiftWrap}
                  className="rounded accent-stone-900"
                />
                <span className="flex items-center gap-1.5">
                  <Gift className="w-3.5 h-3.5 text-stone-700" />
                  Add signature gift packaging (+₹49)
                </span>
              </label>
            </div>

            {/* Price Breakdown */}
            <div className="space-y-1.5 text-xs text-stone-600 pt-2 border-t border-stone-200">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-semibold text-stone-900 tabular-nums">₹{rawSubtotal}</span>
              </div>

              {hasBundlePromo && (
                <div className="flex justify-between text-amber-700 font-medium">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    Buy 2 Tops 10% Discount
                  </span>
                  <span className="tabular-nums">-₹{bundleDiscount}</span>
                </div>
              )}

              {couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Coupon Discount ({appliedCoupon})</span>
                  <span className="tabular-nums">-₹{couponDiscount}</span>
                </div>
              )}

              {giftWrap && (
                <div className="flex justify-between text-stone-700">
                  <span>Gift Wrapping</span>
                  <span className="tabular-nums">+₹49</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Shipping</span>
                <span className="tabular-nums">
                  {shippingFee === 0 ? (
                    <span className="text-emerald-700 font-bold uppercase text-[11px]">Free</span>
                  ) : (
                    `₹${shippingFee}`
                  )}
                </span>
              </div>

              <div className="flex justify-between text-sm font-bold text-stone-950 pt-2 border-t border-stone-200">
                <span>Total Amount</span>
                <span className="text-base tabular-nums">₹{finalTotal}</span>
              </div>

              {totalSavings > 0 && (
                <p className="text-[11px] text-emerald-700 font-medium text-center bg-emerald-50 py-1 rounded">
                  🎉 Total savings on this order: ₹{totalSavings}
                </p>
              )}
            </div>

            {/* Checkout Action Button */}
            <button
              onClick={onCheckout}
              className="w-full min-h-[48px] py-3.5 px-4 bg-stone-950 hover:bg-stone-800 active:scale-95 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-3 text-[11px] text-stone-400">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                100% Secure Checkout
              </span>
              <span>·</span>
              <span>UPI, Cards & COD</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
