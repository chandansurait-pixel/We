import React from 'react';
import { X, Check } from 'lucide-react';
import { FilterState, Size } from '../types';
import { SIZES, COLOR_PALETTE, SUB_CATEGORIES } from '../data/products';

interface FilterDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  filters: FilterState;
  onUpdateFilters: (newFilters: Partial<FilterState>) => void;
  onResetFilters: () => void;
  totalFilteredCount: number;
}

export const FilterDrawer: React.FC<FilterDrawerProps> = ({
  isOpen,
  onClose,
  filters,
  onUpdateFilters,
  onResetFilters,
  totalFilteredCount,
}) => {
  if (!isOpen) return null;

  const toggleSize = (size: Size) => {
    const exists = filters.sizes.includes(size);
    const newSizes = exists
      ? filters.sizes.filter((s) => s !== size)
      : [...filters.sizes, size];
    onUpdateFilters({ sizes: newSizes });
  };

  const toggleColor = (colorName: string) => {
    const exists = filters.colors.includes(colorName);
    const newColors = exists
      ? filters.colors.filter((c) => c !== colorName)
      : [...filters.colors, colorName];
    onUpdateFilters({ colors: newColors });
  };

  const fitTypes = ['Fitted', 'Cropped', 'Relaxed', 'Regular'];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex items-end sm:items-stretch sm:justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Drawer */}
      <div className="relative w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-none h-[88vh] sm:h-full shadow-2xl flex flex-col z-10 animate-sheet-up">
        {/* Mobile Grab Handle */}
        <div className="sm:hidden w-full pt-3 pb-1 flex justify-center bg-white shrink-0">
          <div className="w-12 h-1.5 bg-stone-300 rounded-full" />
        </div>

        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-stone-900">Refine Collection</h2>
            <p className="text-xs text-stone-500">Filter tops by size, price, color & fit</p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center text-stone-500 hover:text-stone-900 rounded-full hover:bg-stone-100 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Filters Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Subcategory */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900 mb-3">
              Silhouette / Category
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {SUB_CATEGORIES.map((cat) => {
                const isSelected = (filters.subCategory || 'All Tops') === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => onUpdateFilters({ subCategory: cat === 'All Tops' ? '' : cat })}
                    className={`py-2 px-3 text-xs font-medium rounded-lg text-left transition-colors border ${
                      isSelected
                        ? 'border-stone-900 bg-stone-900 text-white'
                        : 'border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Size Filter */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900">
                Size
              </h3>
              {filters.sizes.length > 0 && (
                <button
                  onClick={() => onUpdateFilters({ sizes: [] })}
                  className="text-[11px] text-stone-400 hover:text-stone-700"
                >
                  Clear sizes
                </button>
              )}
            </div>
            <div className="grid grid-cols-6 gap-2">
              {SIZES.map((size) => {
                const isSelected = filters.sizes.includes(size);
                return (
                  <button
                    key={size}
                    onClick={() => toggleSize(size)}
                    className={`py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-stone-900 bg-stone-900 text-white shadow-xs'
                        : 'border-stone-200 bg-white text-stone-800 hover:border-stone-400'
                    }`}
                  >
                    {size}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900">
                Price (INR)
              </h3>
              <span className="text-xs font-semibold text-stone-900">
                ₹{filters.priceRange[0]} - ₹{filters.priceRange[1]}
              </span>
            </div>
            <input
              type="range"
              min={600}
              max={1500}
              step={50}
              value={filters.priceRange[1]}
              onChange={(e) =>
                onUpdateFilters({ priceRange: [filters.priceRange[0], parseInt(e.target.value)] })
              }
              className="w-full accent-stone-900 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-stone-400 mt-1">
              <span>Min: ₹600</span>
              <span>Max: ₹1,500</span>
            </div>
          </div>

          {/* Color Filter */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900">
                Color Palette
              </h3>
              {filters.colors.length > 0 && (
                <button
                  onClick={() => onUpdateFilters({ colors: [] })}
                  className="text-[11px] text-stone-400 hover:text-stone-700"
                >
                  Clear colors
                </button>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2">
              {COLOR_PALETTE.map((color) => {
                const isSelected = filters.colors.includes(color.name);
                return (
                  <button
                    key={color.name}
                    onClick={() => toggleColor(color.name)}
                    className={`flex items-center gap-2 p-2 rounded-lg border text-xs text-left transition-colors ${
                      isSelected
                        ? 'border-stone-900 bg-stone-50 font-medium text-stone-900'
                        : 'border-stone-200 text-stone-600 hover:border-stone-300'
                    }`}
                  >
                    <span
                      className="w-4 h-4 rounded-full border border-stone-300 shrink-0"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span className="truncate">{color.name}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 ml-auto text-stone-900" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Fit Type */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900 mb-3">
              Fit Type
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {fitTypes.map((fit) => {
                const isSelected = filters.fitType === fit;
                return (
                  <button
                    key={fit}
                    onClick={() => onUpdateFilters({ fitType: isSelected ? '' : fit })}
                    className={`py-2 px-3 text-xs font-medium rounded-lg text-left transition-colors border ${
                      isSelected
                        ? 'border-stone-900 bg-stone-900 text-white'
                        : 'border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100'
                    }`}
                  >
                    {fit} Fit
                  </button>
                );
              })}
            </div>
          </div>

          {/* Availability */}
          <div className="pt-2 border-t border-stone-100">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.inStockOnly}
                onChange={(e) => onUpdateFilters({ inStockOnly: e.target.checked })}
                className="w-4 h-4 rounded accent-stone-900"
              />
              <span className="text-xs font-medium text-stone-800">
                In Stock & Ready to Ship only
              </span>
            </label>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 pb-safe border-t border-stone-200 bg-stone-50 flex items-center gap-3">
          <button
            onClick={onResetFilters}
            className="flex-1 min-h-[44px] py-2.5 px-4 border border-stone-300 text-stone-700 hover:bg-white active:scale-95 text-xs font-semibold rounded-xl transition-all cursor-pointer"
          >
            Reset All
          </button>
          <button
            onClick={onClose}
            className="flex-1 min-h-[44px] py-2.5 px-4 bg-stone-900 hover:bg-stone-800 active:scale-95 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-md"
          >
            View ({totalFilteredCount}) Styles
          </button>
        </div>
      </div>
    </div>
  );
};
