import React from 'react';
import { Truck, RefreshCw, ShieldCheck, HeartHandshake, PhoneCall } from 'lucide-react';

export const TrustBanner: React.FC = () => {
  const trustPoints = [
    {
      icon: Truck,
      title: 'Free Shipping Over ₹999',
      subtitle: 'Fast delivery to 19,000+ pincodes in India',
    },
    {
      icon: RefreshCw,
      title: '7-Day Easy Exchanges',
      subtitle: 'Doorstep size replacement with zero hassle',
    },
    {
      icon: ShieldCheck,
      title: '100% Quality Guaranteed',
      subtitle: 'Premium breathable fabrics & double stitching',
    },
    {
      icon: PhoneCall,
      title: 'Direct WhatsApp Support',
      subtitle: 'Instant sizing & tracking assistance',
    },
  ];

  return (
    <div className="bg-white border-y border-stone-200 py-10 my-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trustPoints.map((point, idx) => {
            const IconComponent = point.icon;
            return (
              <div key={idx} className="flex items-start gap-3.5 p-3 rounded-xl hover:bg-stone-50 transition-colors">
                <div className="p-2.5 bg-stone-100 rounded-lg text-stone-900 shrink-0">
                  <IconComponent className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wide">
                    {point.title}
                  </h4>
                  <p className="text-xs text-stone-500 mt-0.5 leading-relaxed">
                    {point.subtitle}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
