import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  CreditCard, 
  QrCode, 
  Truck, 
  ShieldCheck, 
  ArrowLeft, 
  Check, 
  ShoppingBag,
  Sparkles,
  Phone,
  Mail,
  MapPin,
  Lock
} from 'lucide-react';
import { CartItem, ShippingAddress, OrderConfirmation } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  total: number;
  onOrderSuccess: (order: OrderConfirmation) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  subtotal,
  discount,
  shippingFee,
  total,
  onOrderSuccess,
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<'address' | 'payment' | 'success'>('address');
  const [formData, setFormData] = useState<ShippingAddress>({
    fullName: '',
    phone: '',
    email: '',
    pincode: '',
    city: '',
    state: 'Maharashtra',
    street: '',
    paymentMethod: 'upi',
    upiApp: 'Google Pay',
  });

  const [cardDetails, setCardDetails] = useState({
    cardNumber: '',
    expiry: '',
    cvv: '',
    cardholder: '',
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<OrderConfirmation | null>(null);

  // Auto-fill City & State on Indian pincode
  const handlePincodeChange = (pin: string) => {
    const cleanPin = pin.replace(/\D/g, '').slice(0, 6);
    setFormData((prev) => ({ ...prev, pincode: cleanPin }));

    if (cleanPin.length === 6) {
      if (cleanPin.startsWith('11')) setFormData((p) => ({ ...p, city: 'New Delhi', state: 'Delhi' }));
      else if (cleanPin.startsWith('40')) setFormData((p) => ({ ...p, city: 'Mumbai', state: 'Maharashtra' }));
      else if (cleanPin.startsWith('56')) setFormData((p) => ({ ...p, city: 'Bengaluru', state: 'Karnataka' }));
      else if (cleanPin.startsWith('70')) setFormData((p) => ({ ...p, city: 'Kolkata', state: 'West Bengal' }));
      else if (cleanPin.startsWith('60')) setFormData((p) => ({ ...p, city: 'Chennai', state: 'Tamil Nadu' }));
      else if (cleanPin.startsWith('50')) setFormData((p) => ({ ...p, city: 'Hyderabad', state: 'Telangana' }));
      else if (cleanPin.startsWith('30')) setFormData((p) => ({ ...p, city: 'Jaipur', state: 'Rajasthan' }));
      else if (cleanPin.startsWith('41')) setFormData((p) => ({ ...p, city: 'Pune', state: 'Maharashtra' }));
      else if (cleanPin.startsWith('38')) setFormData((p) => ({ ...p, city: 'Ahmedabad', state: 'Gujarat' }));
      else if (cleanPin.startsWith('22')) setFormData((p) => ({ ...p, city: 'Lucknow', state: 'Uttar Pradesh' }));
    }
  };

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.phone || !formData.pincode || !formData.street) return;
    setStep('payment');
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      const randomOrderId = `ORG-IND-${Math.floor(100000 + Math.random() * 900000)}`;
      const order: OrderConfirmation = {
        orderId: randomOrderId,
        createdAt: new Date().toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        }),
        items: [...items],
        shippingAddress: { ...formData },
        subtotal,
        discount,
        shippingFee,
        total,
        paymentMethod:
          formData.paymentMethod === 'upi'
            ? `UPI (${formData.upiApp || 'Instant'})`
            : formData.paymentMethod === 'card'
            ? 'Credit / Debit Card'
            : 'Cash on Delivery (COD)',
        estimatedDelivery: '3 to 5 business days',
      };
      setConfirmedOrder(order);
      setStep('success');
      onOrderSuccess(order);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[92vh] sm:h-auto sm:max-h-[92vh] animate-sheet-up">
        {/* Mobile Grab Handle */}
        <div className="sm:hidden w-full pt-3 pb-1 flex justify-center bg-stone-50 shrink-0">
          <div className="w-12 h-1.5 bg-stone-300 rounded-full" />
        </div>

        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-2">
            {step === 'payment' && (
              <button
                onClick={() => setStep('address')}
                className="min-w-[36px] min-h-[36px] flex items-center justify-center text-stone-500 hover:text-stone-900 mr-1 active:scale-90"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <span className="font-display font-extrabold text-sm tracking-wider uppercase text-stone-900">
                ORGAVO CHECKOUT
              </span>
              <p className="text-[11px] text-stone-500">
                {step === 'address'
                  ? 'Step 1: Shipping Details'
                  : step === 'payment'
                  ? 'Step 2: Secure Payment'
                  : 'Order Confirmed!'}
              </p>
            </div>
          </div>
          {step !== 'success' && (
            <button
              onClick={onClose}
              className="min-w-[38px] min-h-[38px] flex items-center justify-center text-stone-400 hover:text-stone-800 rounded-full hover:bg-stone-200/50 active:scale-90"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1">
          {/* STEP 1: Shipping Address */}
          {step === 'address' && (
            <form onSubmit={handleAddressSubmit} className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-stone-100">
                <span className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-stone-700" />
                  Delivery Address (India)
                </span>
                <span className="text-xs text-stone-500">{items.length} items • ₹{total}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="e.g. Diya Sen"
                    className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-stone-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                    Mobile Number (for delivery updates) *
                  </label>
                  <div className="flex">
                    <span className="inline-flex items-center px-2.5 bg-stone-100 border border-r-0 border-stone-300 rounded-l-lg text-xs text-stone-600 font-semibold">
                      +91
                    </span>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          phone: e.target.value.replace(/\D/g, '').slice(0, 10),
                        })
                      }
                      placeholder="9876543210"
                      className="w-full bg-white border border-stone-300 rounded-r-lg px-3 py-2 text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-stone-900"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                  Email Address (for order receipt)
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="diya@example.com"
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-stone-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                    Pincode *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={formData.pincode}
                    onChange={(e) => handlePincodeChange(e.target.value)}
                    placeholder="e.g. 400001"
                    className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-stone-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="e.g. Mumbai"
                    className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-stone-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                    State *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    placeholder="e.g. Maharashtra"
                    className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-stone-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                  Flat, House No., Building, Street *
                </label>
                <textarea
                  required
                  rows={2}
                  value={formData.street}
                  onChange={(e) => setFormData({ ...formData, street: e.target.value })}
                  placeholder="e.g. Flat 402, Sunshine Apartments, Linking Road, Bandra West"
                  className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-stone-900"
                />
              </div>

              <div className="pt-3 border-t border-stone-200 flex items-center justify-between">
                <span className="text-xs text-stone-600">
                  Total Payable: <strong className="text-sm font-bold text-stone-950">₹{total}</strong>
                </span>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-stone-950 hover:bg-stone-800 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer shadow-sm"
                >
                  Continue to Payment
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: Payment Method */}
          {step === 'payment' && (
            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-stone-100">
                <span className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-emerald-600" />
                  Select Payment Option
                </span>
                <span className="text-xs font-semibold text-stone-900">Total: ₹{total}</span>
              </div>

              {/* Payment Methods Tabs */}
              <div className="space-y-3">
                {/* UPI Option */}
                <label
                  className={`block p-3.5 rounded-xl border cursor-pointer transition-all ${
                    formData.paymentMethod === 'upi'
                      ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-900'
                      : 'border-stone-200 bg-white hover:border-stone-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <input
                        type="radio"
                        name="paymentMethod"
                        checked={formData.paymentMethod === 'upi'}
                        onChange={() => setFormData({ ...formData, paymentMethod: 'upi' })}
                        className="accent-stone-900"
                      />
                      <div>
                        <p className="text-xs font-bold text-stone-900">
                          Instant UPI (GPay, PhonePe, Paytm, QR)
                        </p>
                        <p className="text-[11px] text-emerald-700 font-medium">
                          ⚡ Instant confirmation & priority packing
                        </p>
                      </div>
                    </div>
                    <QrCode className="w-5 h-5 text-stone-600" />
                  </div>

                  {formData.paymentMethod === 'upi' && (
                    <div className="mt-3 pt-3 border-t border-stone-200 space-y-2.5">
                      <div className="flex gap-2">
                        {['Google Pay', 'PhonePe', 'Paytm', 'Scan QR'].map((app) => (
                          <button
                            key={app}
                            type="button"
                            onClick={() => setFormData({ ...formData, upiApp: app })}
                            className={`flex-1 py-1.5 text-[11px] font-semibold rounded-lg border transition-colors ${
                              formData.upiApp === app
                                ? 'bg-stone-900 text-white border-stone-900'
                                : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-100'
                            }`}
                          >
                            {app}
                          </button>
                        ))}
                      </div>
                      <div className="p-2.5 bg-white border border-stone-200 rounded-lg text-center">
                        <p className="text-[11px] text-stone-600">
                          Fast UPI checkout enabled for <strong>{formData.upiApp}</strong>.
                        </p>
                      </div>
                    </div>
                  )}
                </label>

                {/* Card Option */}
                <label
                  className={`block p-3.5 rounded-xl border cursor-pointer transition-all ${
                    formData.paymentMethod === 'card'
                      ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-900'
                      : 'border-stone-200 bg-white hover:border-stone-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <input
                        type="radio"
                        name="paymentMethod"
                        checked={formData.paymentMethod === 'card'}
                        onChange={() => setFormData({ ...formData, paymentMethod: 'card' })}
                        className="accent-stone-900"
                      />
                      <div>
                        <p className="text-xs font-bold text-stone-900">
                          Credit / Debit Card (Visa, Mastercard, RuPay)
                        </p>
                        <p className="text-[11px] text-stone-500">
                          Encrypted 256-bit secure gateway
                        </p>
                      </div>
                    </div>
                    <CreditCard className="w-5 h-5 text-stone-600" />
                  </div>

                  {formData.paymentMethod === 'card' && (
                    <div className="mt-3 pt-3 border-t border-stone-200 space-y-2.5">
                      <input
                        type="text"
                        placeholder="Card Number (e.g. 4532 •••• •••• ••••)"
                        value={cardDetails.cardNumber}
                        onChange={(e) => setCardDetails({ ...cardDetails, cardNumber: e.target.value })}
                        className="w-full bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs"
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          placeholder="MM / YY"
                          value={cardDetails.expiry}
                          onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                          className="bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs"
                        />
                        <input
                          type="password"
                          maxLength={4}
                          placeholder="CVV"
                          value={cardDetails.cvv}
                          onChange={(e) => setCardDetails({ ...cardDetails, cvv: e.target.value })}
                          className="bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs"
                        />
                      </div>
                    </div>
                  )}
                </label>

                {/* Cash On Delivery Option */}
                <label
                  className={`block p-3.5 rounded-xl border cursor-pointer transition-all ${
                    formData.paymentMethod === 'cod'
                      ? 'border-stone-900 bg-stone-50 ring-1 ring-stone-900'
                      : 'border-stone-200 bg-white hover:border-stone-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <input
                        type="radio"
                        name="paymentMethod"
                        checked={formData.paymentMethod === 'cod'}
                        onChange={() => setFormData({ ...formData, paymentMethod: 'cod' })}
                        className="accent-stone-900"
                      />
                      <div>
                        <p className="text-xs font-bold text-stone-900">
                          Cash on Delivery (COD)
                        </p>
                        <p className="text-[11px] text-stone-500">
                          Pay cash or UPI at your doorstep upon arrival
                        </p>
                      </div>
                    </div>
                    <Truck className="w-5 h-5 text-stone-600" />
                  </div>
                </label>
              </div>

              {/* Security info */}
              <div className="p-3 bg-stone-100 rounded-xl text-[11px] text-stone-600 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>By placing this order, you agree to 7-day hassle-free replacement terms.</span>
              </div>

              {/* Submit Button */}
              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep('address')}
                  className="text-xs font-semibold text-stone-600 hover:text-stone-900"
                >
                  Edit Address
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-6 py-2.5 bg-stone-950 hover:bg-stone-800 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer shadow-sm flex items-center gap-2"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Placing Order...</span>
                    </>
                  ) : (
                    <span>Confirm & Pay ₹{total}</span>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: Order Confirmation */}
          {step === 'success' && confirmedOrder && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="text-[11px] font-bold uppercase tracking-widest text-amber-600">
                  Congratulations!
                </span>
                <h3 className="font-display text-2xl font-bold text-stone-950 mt-1">
                  Order Successfully Placed
                </h3>
                <p className="text-xs text-stone-500 mt-1">
                  Order ID: <strong className="text-stone-900">{confirmedOrder.orderId}</strong>
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 text-left text-xs space-y-2 max-w-md mx-auto">
                <div className="flex justify-between border-b border-stone-200 pb-2">
                  <span className="text-stone-500">Delivery To:</span>
                  <span className="font-semibold text-stone-900">{confirmedOrder.shippingAddress.fullName}</span>
                </div>
                <div className="flex justify-between border-b border-stone-200 pb-2">
                  <span className="text-stone-500">Shipping Address:</span>
                  <span className="font-semibold text-stone-900 text-right max-w-xs truncate">
                    {confirmedOrder.shippingAddress.street}, {confirmedOrder.shippingAddress.city} - {confirmedOrder.shippingAddress.pincode}
                  </span>
                </div>
                <div className="flex justify-between border-b border-stone-200 pb-2">
                  <span className="text-stone-500">Estimated Delivery:</span>
                  <span className="font-semibold text-stone-900">{confirmedOrder.estimatedDelivery}</span>
                </div>
                <div className="flex justify-between border-b border-stone-200 pb-2">
                  <span className="text-stone-500">Payment:</span>
                  <span className="font-semibold text-stone-900">{confirmedOrder.paymentMethod}</span>
                </div>
                <div className="flex justify-between pt-1">
                  <span className="font-bold text-stone-900">Total Paid / COD:</span>
                  <span className="font-bold text-base text-stone-950">₹{confirmedOrder.total}</span>
                </div>
              </div>

              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                A confirmation SMS & WhatsApp invoice will be sent to +91 {confirmedOrder.shippingAddress.phone}.
              </p>

              <div className="pt-4">
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 bg-stone-950 hover:bg-stone-800 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer shadow-sm"
                >
                  Continue Shopping Tops
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
