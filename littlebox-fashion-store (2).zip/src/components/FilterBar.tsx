import React from 'react';
import { SlidersHorizontal, Grid2X2, Grid3X3, LayoutGrid, X } from 'lucide-react';
import { FilterState, Size } from '../types';
import { SUB_CATEGORIES } from '../data/products';

interface FilterBarProps {
  filters: FilterState;
  onUpdateFilters: (newFilters: Partial<FilterState>) => void;
  onOpenFilterDrawer: () => void;
  totalFilteredCount: number;
  totalCount: number;
  gridCols: 1 | 2 | 3 | 4;
  onChangeGridCols: (cols: 1 | 2 | 3 | 4) => void;
  onResetFilters: () => void;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onUpdateFilters,
  onOpenFilterDrawer,
  totalFilteredCount,
  totalCount,
  gridCols,
  onChangeGridCols,
  onResetFilters,
}) => {
  // Count active filters (excluding default values)
  const activeFilterCount =
    (filters.subCategory && filters.subCategory !== 'All Tops' ? 1 : 0) +
    filters.sizes.length +
    filters.colors.length +
    (filters.fitType ? 1 : 0) +
    (filters.inStockOnly ? 1 : 0) +
    (filters.priceRange[0] > 500 || filters.priceRange[1] < 2000 ? 1 : 0) +
    (filters.searchQuery ? 1 : 0);

  return (
    <div className="py-4 space-y-3">
      {/* Subcategory scrollable bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {SUB_CATEGORIES.map((cat) => {
          const isSelected = (filters.subCategory || 'All Tops') === cat;
          return (
            <button
              key={cat}
              onClick={() => onUpdateFilters({ subCategory: cat === 'All Tops' ? '' : cat })}
              className={`px-3.5 py-1.5 rounded-full font-medium whitespace-nowrap transition-colors cursor-pointer ${
                isSelected
                  ? 'bg-stone-900 text-white shadow-xs'
                  : 'bg-white text-stone-600 border border-stone-200 hover:border-stone-300 hover:text-stone-900'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Second Row: Filter drawer button, Sort selector, count, and grid layout switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-stone-200">
        <div className="flex items-center gap-2">
          {/* Filter Drawer Trigger Button */}
          <button
            onClick={onOpenFilterDrawer}
            className="flex items-center gap-2 px-3.5 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-semibold text-stone-800 hover:bg-stone-50 transition-colors cursor-pointer shadow-xs"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-stone-600" />
            <span>Filters</span>
            {activeFilterCount > 0 && (
              <span className="w-4 h-4 bg-stone-900 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>

          {/* Results Count */}
          <span className="text-xs text-stone-500 font-medium">
            Showing <strong className="text-stone-900 font-semibold">{totalFilteredCount}</strong> of {totalCount} styles
          </span>
        </div>

        {/* Right: Sort By + Mobile/Desktop Grid Column Switcher */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Mobile 1-col / 2-col switcher */}
          <div className="flex md:hidden items-center bg-stone-100 p-0.5 rounded-lg border border-stone-200">
            <button
              onClick={() => onChangeGridCols(1)}
              title="1 Column"
              className={`p-1.5 rounded-md transition-colors ${
                gridCols === 1 ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-400'
              }`}
            >
              <div className="w-3.5 h-3.5 border-2 border-current rounded-xs" />
            </button>
            <button
              onClick={() => onChangeGridCols(2)}
              title="2 Columns"
              className={`p-1.5 rounded-md transition-colors ${
                gridCols === 2 ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-400'
              }`}
            >
              <Grid2X2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Sort By Dropdown */}
          <div className="flex items-center gap-1 text-xs text-stone-600">
            <label htmlFor="sort-select" className="hidden sm:inline font-medium">
              Sort:
            </label>
            <select
              id="sort-select"
              value={filters.sortBy}
              onChange={(e) => onUpdateFilters({ sortBy: e.target.value as any })}
              className="bg-white border border-stone-300 text-stone-800 rounded-lg px-2 py-1.5 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-stone-900 cursor-pointer"
            >
              <option value="featured">Featured</option>
              <option value="bestselling">Bestsellers</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
              <option value="newest">New Arrivals</option>
            </select>
          </div>

          {/* Desktop Column Grid View Toggle */}
          <div className="hidden md:flex items-center bg-stone-100 p-0.5 rounded-lg border border-stone-200">
            <button
              onClick={() => onChangeGridCols(2)}
              title="2 Columns"
              className={`p-1.5 rounded-md transition-colors ${
                gridCols === 2 ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              <Grid2X2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onChangeGridCols(3)}
              title="3 Columns"
              className={`p-1.5 rounded-md transition-colors ${
                gridCols === 3 ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onChangeGridCols(4)}
              title="4 Columns"
              className={`p-1.5 rounded-md transition-colors ${
                gridCols === 4 ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-400 hover:text-stone-700'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Active Filter Chips */}
      {activeFilterCount > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 pt-1 text-xs">
          <span className="text-stone-400 text-[11px] font-medium mr-1">Active:</span>

          {filters.searchQuery && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md text-[11px]">
              Search: "{filters.searchQuery}"
              <button onClick={() => onUpdateFilters({ searchQuery: '' })} className="hover:text-stone-950">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.subCategory && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md text-[11px]">
              Category: {filters.subCategory}
              <button onClick={() => onUpdateFilters({ subCategory: '' })} className="hover:text-stone-950">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.sizes.map((s) => (
            <span key={s} className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md text-[11px]">
              Size: {s}
              <button
                onClick={() => onUpdateFilters({ sizes: filters.sizes.filter((size) => size !== s) })}
                className="hover:text-stone-950"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}

          {filters.colors.map((c) => (
            <span key={c} className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md text-[11px]">
              Color: {c}
              <button
                onClick={() => onUpdateFilters({ colors: filters.colors.filter((color) => color !== c) })}
                className="hover:text-stone-950"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}

          {filters.fitType && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md text-[11px]">
              Fit: {filters.fitType}
              <button onClick={() => onUpdateFilters({ fitType: '' })} className="hover:text-stone-950">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          {filters.inStockOnly && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-800 rounded-md text-[11px]">
              In Stock Only
              <button onClick={() => onUpdateFilters({ inStockOnly: false })} className="hover:text-stone-950">
                <X className="w-3 h-3" />
              </button>
            </span>
          )}

          <button
            onClick={onResetFilters}
            className="text-[11px] text-rose-600 hover:text-rose-700 font-medium underline ml-2 cursor-pointer"
          >
            Clear all
          </button>
        </div>
      )}
    </div>
  );
};
