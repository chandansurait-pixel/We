import React from 'react';
import { Sparkles, SlidersHorizontal, Heart, ShoppingBag } from 'lucide-react';
import { CartItem } from '../types';

interface MobileBottomNavProps {
  activeTab: 'home' | 'filter' | 'wishlist' | 'cart';
  onOpenFilter: () => void;
  onOpenWishlist: () => void;
  onOpenCart: () => void;
  onScrollToTop: () => void;
  cartItems: CartItem[];
  wishlistIds: string[];
  activeFilterCount: number;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  onOpenFilter,
  onOpenWishlist,
  onOpenCart,
  onScrollToTop,
  cartItems,
  wishlistIds,
  activeFilterCount,
}) => {
  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  return (
    <nav
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200/90 pb-safe shadow-[0_-4px_20px_rgba(0,0,0,0.06)]"
    >
      <div className="grid grid-cols-4 items-center h-14 px-2">
        {/* Tab 1: Explore Tops */}
        <button
          onClick={onScrollToTop}
          className="flex flex-col items-center justify-center min-h-[44px] text-stone-700 active:scale-90 transition-transform cursor-pointer relative"
        >
          <Sparkles className="w-5 h-5 text-stone-900" />
          <span className="text-[10px] font-bold tracking-tight text-stone-900 mt-0.5">Explore</span>
        </button>

        {/* Tab 2: Filters */}
        <button
          onClick={onOpenFilter}
          className="flex flex-col items-center justify-center min-h-[44px] text-stone-700 active:scale-90 transition-transform cursor-pointer relative"
        >
          <div className="relative">
            <SlidersHorizontal className="w-5 h-5 text-stone-700" />
            {activeFilterCount > 0 && (
              <span className="absolute -top-1 -right-2 w-4 h-4 bg-stone-950 text-white rounded-full text-[9px] font-bold flex items-center justify-center animate-badge-bounce">
                {activeFilterCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-medium tracking-tight text-stone-600 mt-0.5">Filters</span>
        </button>

        {/* Tab 3: Wishlist */}
        <button
          onClick={onOpenWishlist}
          className="flex flex-col items-center justify-center min-h-[44px] text-stone-700 active:scale-90 transition-transform cursor-pointer relative"
        >
          <div className="relative">
            <Heart
              className={`w-5 h-5 ${
                wishlistIds.length > 0 ? 'text-rose-500 fill-current animate-heart-pop' : 'text-stone-700'
              }`}
            />
            {wishlistIds.length > 0 && (
              <span className="absolute -top-1 -right-2 w-4 h-4 bg-rose-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                {wishlistIds.length}
              </span>
            )}
          </div>
          <span className="text-[10px] font-medium tracking-tight text-stone-600 mt-0.5">Wishlist</span>
        </button>

        {/* Tab 4: Bag */}
        <button
          onClick={onOpenCart}
          className="flex flex-col items-center justify-center min-h-[44px] text-stone-900 active:scale-90 transition-transform cursor-pointer relative"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5 text-stone-950" />
            {totalCartCount > 0 && (
              <span className="absolute -top-1 -right-2.5 w-4 h-4 bg-amber-400 text-stone-950 rounded-full text-[9px] font-bold flex items-center justify-center animate-badge-bounce shadow-xs">
                {totalCartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold tracking-tight text-stone-950 mt-0.5">
            {totalCartCount > 0 ? `₹${cartSubtotal}` : 'Bag'}
          </span>
        </button>
      </div>
    </nav>
  );
};
