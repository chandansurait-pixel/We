import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  Heart, 
  Search, 
  Menu, 
  X, 
  Sparkles, 
  Truck, 
  Tag, 
  ChevronRight,
  SlidersHorizontal
} from 'lucide-react';
import { CartItem, Product } from '../types';

interface HeaderProps {
  cartItems: CartItem[];
  wishlistIds: string[];
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onSelectCategory: (cat: string) => void;
  activeCategory: string;
  onSearch: (query: string) => void;
  searchQuery: string;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartItems,
  wishlistIds,
  onOpenCart,
  onOpenWishlist,
  onSelectCategory,
  activeCategory,
  onSearch,
  searchQuery,
  products,
  onSelectProduct,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [tickerIndex, setTickerIndex] = useState(0);

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const announcements = [
    { text: 'FREE SHIPPING ACROSS INDIA ON ORDERS OVER ₹999', icon: Truck },
    { text: 'EXTRA 10% OFF ON ALL TOPS: USE CODE TRENDY10', icon: Tag },
    { text: 'BUY 2 TOPS GET 10% OFF • AUTO APPLIED AT CHECKOUT', icon: Sparkles },
    { text: 'EASY 7-DAY HASSLE-FREE RETURNS & EXCHANGES', icon: Truck },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % announcements.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [announcements.length]);

  const navCategories = [
    { label: 'All Tops', value: 'All Tops' },
    { label: 'Corsets', value: 'Corsets' },
    { label: 'Baby Tees', value: 'Baby Tees' },
    { label: 'Knitwear', value: 'Knitwear' },
    { label: 'Blouses', value: 'Blouses' },
    { label: 'Party Tops', value: 'Party Tops' },
  ];

  const CurrentIcon = announcements[tickerIndex].icon;

  const searchResults = searchQuery.trim()
    ? products.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.subCategory.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-stone-200">
      {/* Top Ticker Bar */}
      <div className="bg-stone-900 text-stone-100 text-[11px] sm:text-xs py-2 px-4 transition-colors">
        <div className="max-w-7xl mx-auto flex items-center justify-center text-center">
          <div className="flex items-center gap-2 font-medium tracking-wide">
            <CurrentIcon className="w-3.5 h-3.5 text-amber-300 shrink-0" />
            <span className="truncate">{announcements[tickerIndex].text}</span>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Mobile Menu Button & Search Trigger */}
        <div className="flex items-center gap-1 lg:hidden">
          <button
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open Navigation Menu"
            className="min-w-[42px] min-h-[42px] flex items-center justify-center text-stone-800 hover:text-stone-950 active:scale-90 transition-transform focus:outline-none rounded-full"
          >
            <Menu className="w-5 h-5" />
          </button>
          <button
            onClick={() => setSearchOpen(true)}
            aria-label="Open Search"
            className="min-w-[42px] min-h-[42px] flex items-center justify-center text-stone-800 hover:text-stone-950 active:scale-90 transition-transform focus:outline-none rounded-full"
          >
            <Search className="w-5 h-5" />
          </button>
        </div>

        {/* Brand Wordmark (Single Text Element per Top Bar Contract) */}
        <div className="flex items-center">
          <button
            onClick={() => {
              onSelectCategory('All Tops');
              onSearch('');
            }}
            className="text-left group cursor-pointer active:scale-95 transition-transform"
          >
            <span className="font-display text-xl sm:text-3xl font-extrabold tracking-widest text-stone-950 uppercase transition-opacity group-hover:opacity-80">
              ORGAVO
            </span>
          </button>
        </div>

        {/* Desktop Navigation Links (Clean text links with hover states) */}
        <nav className="hidden lg:flex items-center gap-7 text-[13px] font-semibold tracking-wider uppercase text-stone-700">
          {navCategories.map((cat) => {
            const isActive = activeCategory === cat.value && !searchQuery;
            return (
              <button
                key={cat.value}
                onClick={() => {
                  onSelectCategory(cat.value);
                  onSearch('');
                }}
                className={`relative py-1 transition-colors hover:text-stone-950 cursor-pointer ${
                  isActive ? 'text-stone-950 font-bold' : ''
                }`}
              >
                {cat.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-stone-950 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Actions Zone: Search Bar, Wishlist, Bag */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Desktop Search Trigger / Input */}
          <div className="hidden md:flex items-center relative">
            <div className="flex items-center bg-stone-100 hover:bg-stone-200/80 border border-stone-200 rounded-full px-3 py-1.5 transition-colors focus-within:ring-1 focus-within:ring-stone-900 focus-within:bg-white w-48 lg:w-60">
              <Search className="w-4 h-4 text-stone-500 mr-2 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearch(e.target.value)}
                placeholder="Search tops, corsets..."
                className="w-full bg-transparent text-xs text-stone-900 placeholder:text-stone-400 focus:outline-none"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearch('')}
                  className="text-stone-400 hover:text-stone-700"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Wishlist Icon */}
          <button
            onClick={onOpenWishlist}
            aria-label="Wishlist"
            className="relative min-w-[42px] min-h-[42px] flex items-center justify-center text-stone-700 hover:text-stone-950 active:scale-90 transition-all cursor-pointer rounded-full"
          >
            <Heart className="w-5 h-5" />
            {wishlistIds.length > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-rose-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center leading-none animate-badge-bounce">
                {wishlistIds.length}
              </span>
            )}
          </button>

          {/* Shopping Bag Drawer Trigger */}
          <button
            onClick={onOpenCart}
            aria-label="Shopping Bag"
            className="flex items-center gap-2 bg-stone-950 text-white px-3 sm:px-4 min-h-[40px] rounded-full hover:bg-stone-800 active:scale-95 transition-all cursor-pointer shadow-xs"
          >
            <div className="relative">
              <ShoppingBag className="w-4 h-4" />
              {totalCartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-amber-400 text-stone-950 rounded-full text-[10px] font-bold flex items-center justify-center leading-none animate-badge-bounce">
                  {totalCartCount}
                </span>
              )}
            </div>
            <span className="hidden sm:inline text-xs font-semibold tracking-wider uppercase">
              Bag {totalCartCount > 0 && `(${totalCartCount})`}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Search Overlay */}
      {searchOpen && (
        <div className="lg:hidden px-4 py-3 bg-white border-b border-stone-200">
          <div className="flex items-center gap-2">
            <div className="flex-1 flex items-center bg-stone-100 rounded-lg px-3 py-2 border border-stone-300">
              <Search className="w-4 h-4 text-stone-500 mr-2" />
              <input
                autoFocus
                type="text"
                value={searchQuery}
                onChange={(e) => onSearch(e.target.value)}
                placeholder="Search viral corsets, baby tees, knits..."
                className="w-full bg-transparent text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none"
              />
              {searchQuery && (
                <button onClick={() => onSearch('')} className="p-1 text-stone-500">
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            <button
              onClick={() => setSearchOpen(false)}
              className="text-xs font-semibold text-stone-600 px-2 py-2"
            >
              Cancel
            </button>
          </div>

          {searchQuery && searchResults.length > 0 && (
            <div className="mt-3 max-h-72 overflow-y-auto divide-y divide-stone-100">
              {searchResults.slice(0, 5).map((prod) => (
                <div
                  key={prod.id}
                  onClick={() => {
                    onSelectProduct(prod);
                    setSearchOpen(false);
                  }}
                  className="py-2 flex items-center gap-3 cursor-pointer hover:bg-stone-50"
                >
                  <img
                    src={prod.images[0]}
                    alt={prod.name}
                    className="w-10 h-12 object-cover rounded bg-stone-100"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-stone-900 truncate">{prod.name}</p>
                    <p className="text-[11px] text-stone-500">₹{prod.price} <span className="line-through">₹{prod.originalPrice}</span></p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-stone-400" />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-4/5 max-w-xs bg-white h-full shadow-2xl flex flex-col justify-between p-6 z-10">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-stone-200">
                <span className="font-display text-xl font-bold tracking-widest text-stone-950">
                  ORGAVO
                </span>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 text-stone-500 hover:text-stone-900"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="py-4">
                <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-widest mb-3">
                  Tops Categories
                </p>
                <div className="flex flex-col space-y-2">
                  {navCategories.map((cat) => (
                    <button
                      key={cat.value}
                      onClick={() => {
                        onSelectCategory(cat.value);
                        onSearch('');
                        setMobileMenuOpen(false);
                      }}
                      className={`text-left text-sm py-2 px-3 rounded-lg font-medium transition-colors ${
                        activeCategory === cat.value
                          ? 'bg-stone-900 text-white'
                          : 'text-stone-700 hover:bg-stone-100'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-stone-200 space-y-3 text-xs text-stone-600">
                <div className="flex items-center gap-2 text-stone-900 font-medium">
                  <Truck className="w-4 h-4 text-amber-600" />
                  <span>Free shipping on orders ₹999+</span>
                </div>
                <div className="flex items-center gap-2 text-stone-900 font-medium">
                  <Tag className="w-4 h-4 text-emerald-600" />
                  <span>Extra 10% off with TRENDY10</span>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-stone-200">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenWishlist();
                }}
                className="w-full flex items-center justify-between py-2 text-sm text-stone-800 font-medium"
              >
                <span className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-rose-500" />
                  Wishlist
                </span>
                <span className="text-xs bg-stone-100 px-2 py-0.5 rounded-full font-bold">
                  {wishlistIds.length}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
