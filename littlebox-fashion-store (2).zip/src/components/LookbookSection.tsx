import React from 'react';
import { Product } from '../types';
import { ArrowRight, Sparkles } from 'lucide-react';

interface LookbookSectionProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const LookbookSection: React.FC<LookbookSectionProps> = ({ products, onSelectProduct }) => {
  const lookbookItems = [
    {
      title: 'The Y2K Downtown Edge',
      subtitle: 'Structured Corset + Low Rise Utility',
      productId: 'lb-top-01',
      desc: 'Channel 2000s off-duty model energy with our boned lace-up corset paired with relaxed cargo trousers.',
    },
    {
      title: 'Minimalist Clean Girl',
      subtitle: 'Sage Halter Rib + High Rise Linen',
      productId: 'lb-top-02',
      desc: 'Effortlessly polished. The sage ribbed knit hugs contours while keeping the silhouette breezy and elevated.',
    },
    {
      title: 'Romantic European Summer',
      subtitle: 'Ruched Milkmaid + Tiered Skirt',
      productId: 'lb-top-04',
      desc: 'Puff sleeves, sweetheart ruching, and mocha tones made for terrace brunches and golden hour portraits.',
    },
  ];

  return (
    <section className="my-8 sm:my-16 py-8 sm:py-12 bg-stone-100/70 border-y border-stone-200">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 sm:mb-8">
          <div>
            <div className="flex items-center gap-1.5 text-[11px] sm:text-xs font-bold text-amber-700 uppercase tracking-widest mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Curated Lookbook</span>
            </div>
            <h2 className="font-display text-xl sm:text-3xl font-extrabold text-stone-950">
              STYLE THE VIRAL FIT
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-1 max-w-lg">
              Explore how India’s top creators and stylists are pairing our tops this season.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
          {lookbookItems.map((item, idx) => {
            const matchingProd = products.find((p) => p.id === item.productId);
            if (!matchingProd) return null;

            return (
              <div
                key={idx}
                onClick={() => onSelectProduct(matchingProd)}
                className="group relative bg-white rounded-2xl overflow-hidden border border-stone-200/80 hover:shadow-lg transition-all duration-300 active:scale-[0.98] cursor-pointer flex flex-col justify-between"
              >
                <div className="aspect-[4/3] w-full overflow-hidden bg-stone-100 relative">
                  <img
                    src={matchingProd.images[0]}
                    alt={item.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80" />
                  <div className="absolute bottom-3 left-3 right-3 text-white">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300">
                      {item.subtitle}
                    </span>
                    <h3 className="font-display text-base font-bold leading-tight">{item.title}</h3>
                  </div>
                </div>

                <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                  <p className="text-xs text-stone-600 leading-relaxed mb-4">{item.desc}</p>
                  <div className="flex items-center justify-between pt-3 border-t border-stone-100">
                    <div>
                      <span className="text-[11px] text-stone-500 block truncate max-w-[160px]">
                        {matchingProd.name}
                      </span>
                      <span className="text-xs font-bold text-stone-950 tabular-nums">
                        ₹{matchingProd.price}{' '}
                        <span className="text-stone-400 font-normal line-through text-[11px]">
                          ₹{matchingProd.originalPrice}
                        </span>
                      </span>
                    </div>
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-stone-900 group-hover:translate-x-1 transition-transform">
                      Shop Top
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
