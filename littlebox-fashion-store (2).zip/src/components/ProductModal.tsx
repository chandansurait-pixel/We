import React, { useState } from 'react';
import { 
  X, 
  Heart, 
  Star, 
  Truck, 
  ShieldCheck, 
  RefreshCw, 
  Check, 
  Sparkles, 
  Ruler, 
  Share2, 
  Info,
  ChevronRight,
  MapPin,
  Tag,
  ShoppingBag
} from 'lucide-react';
import { Product, Size, ProductColor, Review } from '../types';
import { SIZE_CHART } from '../data/products';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
  onAddToCart: (product: Product, size: Size, color: ProductColor, quantity: number) => void;
  onBuyNow: (product: Product, size: Size, color: ProductColor, quantity: number) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
  onBuyNow,
}) => {
  if (!product) return null;

  const [selectedImgIdx, setSelectedImgIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState<Size>(product.sizes[0] || 'S');
  const [selectedColor, setSelectedColor] = useState<ProductColor>(product.colors[0]);
  const [quantity, setQuantity] = useState(1);
  const [showSizeGuide, setShowSizeGuide] = useState(false);
  const [sizeUnit, setSizeUnit] = useState<'inches' | 'cm'>('inches');
  const [userBust, setUserBust] = useState<string>('');
  const [recommendedSize, setRecommendedSize] = useState<string | null>(null);

  // Delivery Pincode state
  const [pincode, setPincode] = useState('');
  const [pincodeStatus, setPincodeStatus] = useState<{
    checked: boolean;
    valid: boolean;
    message: string;
    metro?: boolean;
  } | null>(null);

  // Review Form state
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewName, setReviewName] = useState('');
  const [reviewLocation, setReviewLocation] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [localReviews, setLocalReviews] = useState<Review[]>(product.reviews);
  const [reviewSuccess, setReviewSuccess] = useState(false);

  // Stock status for current size
  const currentStock = product.sizeStock[selectedSize] ?? 5;
  const isOutOfStock = currentStock === 0;

  // Fit calculator function
  const handleCalculateFit = () => {
    const bustNum = parseFloat(userBust);
    if (!bustNum || isNaN(bustNum)) return;
    
    const bustInches = sizeUnit === 'cm' ? bustNum / 2.54 : bustNum;
    
    if (bustInches <= 32) setRecommendedSize('XS');
    else if (bustInches <= 34) setRecommendedSize('S');
    else if (bustInches <= 36) setRecommendedSize('M');
    else if (bustInches <= 38) setRecommendedSize('L');
    else if (bustInches <= 40) setRecommendedSize('XL');
    else setRecommendedSize('XXL');
  };

  // Indian Pincode Delivery checker
  const handleCheckPincode = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = pincode.trim();
    if (!/^\d{6}$/.test(cleanPin)) {
      setPincodeStatus({
        checked: true,
        valid: false,
        message: 'Please enter a valid 6-digit Indian PIN code.',
      });
      return;
    }

    const isMetro = ['110', '400', '560', '700', '600', '500', '380'].some((prefix) =>
      cleanPin.startsWith(prefix)
    );

    setPincodeStatus({
      checked: true,
      valid: true,
      metro: isMetro,
      message: isMetro
        ? 'Express Delivery in 2-3 business days. Cash on delivery available!'
        : 'Standard Delivery in 3-5 business days. Cash on delivery available!',
    });
  };

  // Submit new review
  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewName.trim() || !reviewComment.trim()) return;

    const newRev: Review = {
      id: `rev-${Date.now()}`,
      author: reviewName.trim(),
      location: reviewLocation.trim() || 'Verified Shopper',
      rating: reviewRating,
      date: 'Just now',
      title: 'Loving this piece!',
      comment: reviewComment.trim(),
      verifiedPurchase: true,
      sizePurchased: selectedSize,
      helpfulCount: 0,
    };

    setLocalReviews([newRev, ...localReviews]);
    setReviewSuccess(true);
    setTimeout(() => {
      setShowReviewForm(false);
      setReviewSuccess(false);
      setReviewName('');
      setReviewComment('');
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 md:p-6 animate-fadeIn">
      {/* Modal / Mobile Bottom Sheet Card */}
      <div className="relative w-full max-w-5xl bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[92vh] sm:h-auto sm:max-h-[92vh] animate-sheet-up">
        {/* Mobile Grab Handle Bar */}
        <div className="sm:hidden w-full pt-3 pb-1 flex justify-center bg-white shrink-0">
          <div className="w-12 h-1.5 bg-stone-300 rounded-full" />
        </div>

        {/* Sticky Top Action Bar */}
        <div className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 flex items-center gap-2">
          <button
            onClick={() => onToggleWishlist(product.id)}
            aria-label="Wishlist"
            className={`min-w-[40px] min-h-[40px] rounded-full flex items-center justify-center transition-all cursor-pointer shadow-md active:scale-125 ${
              isWishlisted
                ? 'bg-rose-50 text-rose-600 animate-heart-pop'
                : 'bg-white/95 text-stone-700 hover:text-rose-600'
            }`}
          >
            <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
          </button>
          <button
            onClick={onClose}
            aria-label="Close"
            className="min-w-[40px] min-h-[40px] bg-white/95 hover:bg-stone-100 rounded-full flex items-center justify-center text-stone-800 transition-all cursor-pointer shadow-md active:scale-90"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Container */}
        <div className="overflow-y-auto flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2">
            {/* Left Column: Image Gallery */}
            <div className="p-4 sm:p-6 bg-stone-50 flex flex-col gap-3">
              {/* Main Active Image */}
              <div className="relative aspect-[3/4] w-full rounded-2xl overflow-hidden bg-stone-200 shadow-xs">
                <img
                  src={product.images[selectedImgIdx] || product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover object-center"
                  referrerPolicy="no-referrer"
                  decoding="async"
                />
                {product.discountPercent > 0 && (
                  <span className="absolute top-3 left-3 bg-rose-600 text-white text-xs font-bold px-2 py-1 rounded-md shadow-xs">
                    SAVE {product.discountPercent}%
                  </span>
                )}

                {/* Mobile Dots Indicator */}
                {product.images.length > 1 && (
                  <div className="absolute bottom-3 inset-x-0 flex items-center justify-center gap-1.5 sm:hidden">
                    {product.images.map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedImgIdx(idx)}
                        className={`h-1.5 rounded-full transition-all ${
                          selectedImgIdx === idx ? 'w-5 bg-white' : 'w-1.5 bg-white/50'
                        }`}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Desktop Thumbnails */}
              {product.images.length > 1 && (
                <div className="hidden sm:flex gap-2">
                  {product.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImgIdx(idx)}
                      className={`relative w-16 h-20 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                        selectedImgIdx === idx ? 'border-stone-900 ring-2 ring-stone-900/20' : 'border-transparent opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={img}
                        alt={`Preview ${idx + 1}`}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </button>
                  ))}
                </div>
              )}

              {/* Trust Badges under gallery */}
              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-stone-200 text-center text-[11px] text-stone-600">
                <div className="flex flex-col items-center gap-1">
                  <Truck className="w-4 h-4 text-stone-800" />
                  <span>Free Express over ₹999</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <RefreshCw className="w-4 h-4 text-stone-800" />
                  <span>7-Day Easy Exchange</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <ShieldCheck className="w-4 h-4 text-stone-800" />
                  <span>100% Quality Verified</span>
                </div>
              </div>
            </div>

            {/* Right Column: Product Detail & Actions Module */}
            <div className="p-4 sm:p-7 flex flex-col justify-between space-y-5">
              <div>
                {/* Category & Rating */}
                <div className="flex items-center justify-between text-xs text-stone-500 mb-1.5">
                  <span className="font-semibold uppercase tracking-wider text-stone-600">
                    {product.subCategory}
                  </span>
                  <div className="flex items-center gap-1 text-stone-800 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{product.rating}</span>
                    <span className="text-stone-400 font-normal">({localReviews.length} reviews)</span>
                  </div>
                </div>

                {/* Title */}
                <h2 className="font-display text-xl sm:text-2xl font-bold text-stone-950 leading-tight">
                  {product.name}
                </h2>

                {/* Price Display */}
                <div className="mt-2.5 flex items-baseline gap-2.5">
                  <span className="text-2xl font-extrabold text-stone-950 tabular-nums">
                    ₹{product.price}
                  </span>
                  <span className="text-sm text-stone-400 line-through tabular-nums">
                    ₹{product.originalPrice}
                  </span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    Save ₹{product.originalPrice - product.price} ({product.discountPercent}%)
                  </span>
                </div>
                <p className="text-[11px] text-stone-400 mt-0.5">Inclusive of all Indian taxes</p>

                {/* Special Promotional Bundle Callout */}
                <div className="mt-4 p-3 bg-amber-50/90 border border-amber-200 rounded-xl flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                    <div>
                      <span className="font-bold text-amber-900">BUY 2 GET 10% OFF</span>
                      <p className="text-amber-800 text-[11px]">Add any 2 tops to bag for automatic extra discount</p>
                    </div>
                  </div>
                  <Tag className="w-4 h-4 text-amber-700 shrink-0" />
                </div>

                {/* Color Selector */}
                <div className="mt-5">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-semibold text-stone-900">Color:</span>
                    <span className="text-stone-600">{selectedColor.name}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {product.colors.map((color) => {
                      const isSelected = selectedColor.name === color.name;
                      return (
                        <button
                          key={color.name}
                          onClick={() => setSelectedColor(color)}
                          className={`flex items-center gap-1.5 min-h-[40px] px-3 py-1.5 rounded-xl border text-xs font-medium transition-all active:scale-95 cursor-pointer ${
                            isSelected
                              ? 'border-stone-900 bg-stone-100 font-bold ring-1 ring-stone-900 shadow-xs'
                              : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                          }`}
                        >
                          <span
                            className="w-3.5 h-3.5 rounded-full border border-stone-300"
                            style={{ backgroundColor: color.hex }}
                          />
                          <span>{color.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Size Selector + Size Guide Button */}
                <div className="mt-5">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-stone-900">Size:</span>
                      {currentStock > 0 && currentStock <= 3 && (
                        <span className="text-[11px] text-amber-600 font-medium animate-pulse">
                          ⚡ Only {currentStock} left!
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => setShowSizeGuide(true)}
                      className="flex items-center gap-1 text-xs text-stone-900 hover:text-stone-950 font-bold underline cursor-pointer p-1 active:scale-95"
                    >
                      <Ruler className="w-3.5 h-3.5" />
                      Size Guide & Fit
                    </button>
                  </div>

                  <div className="grid grid-cols-6 gap-2">
                    {product.sizes.map((size) => {
                      const inStock = (product.sizeStock[size] ?? 0) > 0;
                      const isSelected = selectedSize === size;
                      return (
                        <button
                          key={size}
                          disabled={!inStock}
                          onClick={() => setSelectedSize(size)}
                          className={`min-h-[44px] py-2 text-xs font-bold rounded-xl border transition-all active:scale-90 cursor-pointer ${
                            isSelected
                              ? 'border-stone-950 bg-stone-950 text-white shadow-md'
                              : inStock
                              ? 'border-stone-200 bg-white text-stone-800 hover:border-stone-400 active:bg-stone-100'
                              : 'border-stone-200 bg-stone-100 text-stone-400 cursor-not-allowed line-through'
                          }`}
                        >
                          {size}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Quantity Stepper */}
                <div className="mt-5 flex items-center justify-between border-y border-stone-100 py-3">
                  <span className="text-xs font-semibold text-stone-900">Quantity</span>
                  <div className="flex items-center border border-stone-300 rounded-xl">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      className="min-w-[40px] min-h-[36px] flex items-center justify-center text-stone-600 hover:text-stone-950 text-base font-semibold active:scale-90"
                    >
                      -
                    </button>
                    <span className="px-3 text-xs font-bold text-stone-900 tabular-nums">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => Math.min(currentStock || 5, q + 1))}
                      className="min-w-[40px] min-h-[36px] flex items-center justify-center text-stone-600 hover:text-stone-950 text-base font-semibold active:scale-90"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Desktop Primary CTA Buttons (Hidden on mobile where sticky bar is active) */}
                <div className="hidden sm:flex items-center gap-3 pt-2">
                  <button
                    disabled={isOutOfStock}
                    onClick={() => onAddToCart(product, selectedSize, selectedColor, quantity)}
                    className="flex-1 py-3 px-5 bg-white border-2 border-stone-950 text-stone-950 hover:bg-stone-100 active:scale-95 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer"
                  >
                    Add to Bag
                  </button>
                  <button
                    disabled={isOutOfStock}
                    onClick={() => onBuyNow(product, selectedSize, selectedColor, quantity)}
                    className="flex-1 py-3 px-5 bg-stone-950 hover:bg-stone-800 active:scale-95 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-md"
                  >
                    Instant Buy Now
                  </button>
                </div>

                {/* Pincode Delivery Estimator */}
                <div className="mt-5 p-3.5 bg-stone-50 rounded-xl border border-stone-200">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-stone-900 mb-2">
                    <MapPin className="w-3.5 h-3.5 text-stone-700" />
                    <span>Check Delivery & COD Availability</span>
                  </div>
                  <form onSubmit={handleCheckPincode} className="flex gap-2">
                    <input
                      type="text"
                      maxLength={6}
                      value={pincode}
                      onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
                      placeholder="Enter 6-digit Pincode (e.g. 110001)"
                      className="flex-1 bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-1 focus:ring-stone-900"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-stone-800 active:scale-95 transition-all"
                    >
                      Check
                    </button>
                  </form>
                  {pincodeStatus?.checked && (
                    <div className="mt-2 text-xs">
                      {pincodeStatus.valid ? (
                        <p className="text-emerald-700 font-medium flex items-center gap-1">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{pincodeStatus.message}</span>
                        </p>
                      ) : (
                        <p className="text-rose-600">{pincodeStatus.message}</p>
                      )}
                    </div>
                  )}
                </div>

                {/* Details Accordion / Tabs */}
                <div className="mt-6 pt-5 border-t border-stone-200 space-y-3 text-xs text-stone-700">
                  <div>
                    <h4 className="font-bold text-stone-900 uppercase tracking-wider text-[11px] mb-1">
                      Product Description
                    </h4>
                    <p className="leading-relaxed text-stone-600">{product.description}</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 uppercase tracking-wider text-[11px] mb-1">
                      Fabric & Composition
                    </h4>
                    <ul className="list-disc pl-4 space-y-0.5 text-stone-600">
                      {product.fabricDetails.map((f, i) => (
                        <li key={i}>{f}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 uppercase tracking-wider text-[11px] mb-1">
                      Model Dimensions
                    </h4>
                    <p className="text-stone-600">{product.modelInfo}</p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 uppercase tracking-wider text-[11px] mb-1">
                      How To Style
                    </h4>
                    <p className="text-stone-600">{product.styleTips}</p>
                  </div>
                </div>

                {/* Customer Reviews Section */}
                <div className="mt-8 pt-6 border-t border-stone-200">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-display text-base font-bold text-stone-900">
                        Shopper Reviews ({localReviews.length})
                      </h3>
                      <p className="text-xs text-stone-500">Verified customers from across India</p>
                    </div>
                    <button
                      onClick={() => setShowReviewForm(!showReviewForm)}
                      className="px-3 py-1.5 border border-stone-300 text-stone-800 text-xs font-semibold rounded-lg hover:bg-stone-50 active:scale-95 transition-all"
                    >
                      {showReviewForm ? 'Cancel' : 'Write a Review'}
                    </button>
                  </div>

                  {/* Review Submission Form */}
                  {showReviewForm && (
                    <form onSubmit={handleSubmitReview} className="mb-6 p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-3 animate-fadeIn">
                      <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                        Share your feedback
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <input
                          type="text"
                          required
                          value={reviewName}
                          onChange={(e) => setReviewName(e.target.value)}
                          placeholder="Your Name (e.g. Diya Sharma)"
                          className="bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-stone-900"
                        />
                        <input
                          type="text"
                          value={reviewLocation}
                          onChange={(e) => setReviewLocation(e.target.value)}
                          placeholder="City (e.g. Mumbai)"
                          className="bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-stone-900"
                        />
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-medium text-stone-700">Rating:</span>
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              type="button"
                              onClick={() => setReviewRating(star)}
                              className="p-1 text-amber-400 active:scale-125 transition-transform"
                            >
                              <Star className={`w-4 h-4 ${reviewRating >= star ? 'fill-amber-400' : 'text-stone-300'}`} />
                            </button>
                          ))}
                        </div>
                      </div>
                      <textarea
                        required
                        rows={3}
                        value={reviewComment}
                        onChange={(e) => setReviewComment(e.target.value)}
                        placeholder="Tell others about the fit, fabric quality, and how you styled it..."
                        className="w-full bg-white border border-stone-300 rounded-lg p-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-stone-900"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-stone-800 active:scale-95 transition-all"
                      >
                        {reviewSuccess ? 'Review Posted!' : 'Submit Review'}
                      </button>
                    </form>
                  )}

                  {/* Reviews List */}
                  <div className="space-y-3.5 pb-6">
                    {localReviews.map((rev) => (
                      <div key={rev.id} className="p-3.5 bg-stone-50 rounded-xl text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-stone-900">{rev.author}</span>
                            {rev.verifiedPurchase && (
                              <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-medium">
                                Verified Buyer
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-stone-400">{rev.date}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex text-amber-400">
                            {[...Array(rev.rating)].map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-amber-400" />
                            ))}
                          </div>
                          <span className="text-stone-400 text-[11px]">Size: {rev.sizePurchased}</span>
                          <span className="text-stone-400 text-[11px]">· {rev.location}</span>
                        </div>
                        <p className="font-semibold text-stone-800 pt-0.5">{rev.title}</p>
                        <p className="text-stone-600 leading-relaxed">{rev.comment}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* STICKY BOTTOM BUY BAR FOR MOBILE - Pattern 3 / Layout C */}
        <div className="sm:hidden sticky bottom-0 inset-x-0 bg-white/95 backdrop-blur-md p-3 border-t border-stone-200/90 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] flex items-center gap-2 z-30 pb-safe">
          <button
            disabled={isOutOfStock}
            onClick={() => onAddToCart(product, selectedSize, selectedColor, quantity)}
            className="flex-1 py-3 px-3 bg-white border-2 border-stone-950 text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl active:scale-95 transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Add to Bag</span>
          </button>
          <button
            disabled={isOutOfStock}
            onClick={() => onBuyNow(product, selectedSize, selectedColor, quantity)}
            className="flex-1 py-3 px-3 bg-stone-950 text-white font-bold text-xs uppercase tracking-wider rounded-xl active:scale-95 transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>Buy Now</span>
            <span className="font-extrabold tabular-nums">₹{product.price * quantity}</span>
          </button>
        </div>
      </div>

      {/* Size Guide Modal Sub-Overlay */}
      {showSizeGuide && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div className="relative w-full max-w-lg bg-white rounded-2xl p-4 sm:p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <Ruler className="w-5 h-5 text-stone-900" />
                <h3 className="font-display text-base font-bold text-stone-950">
                  Size Guide & Fit Advisor
                </h3>
              </div>
              <button
                onClick={() => setShowSizeGuide(false)}
                className="min-w-[36px] min-h-[36px] rounded-lg flex items-center justify-center text-stone-400 hover:text-stone-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Inches vs CM toggle */}
            <div className="my-4 flex items-center justify-between">
              <span className="text-xs text-stone-500 font-medium">Measurement Units:</span>
              <div className="flex items-center bg-stone-100 p-0.5 rounded-lg text-xs">
                <button
                  onClick={() => setSizeUnit('inches')}
                  className={`px-3 py-1 rounded-md font-semibold transition-colors ${
                    sizeUnit === 'inches' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
                  }`}
                >
                  Inches
                </button>
                <button
                  onClick={() => setSizeUnit('cm')}
                  className={`px-3 py-1 rounded-md font-semibold transition-colors ${
                    sizeUnit === 'cm' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
                  }`}
                >
                  CM
                </button>
              </div>
            </div>

            {/* Size Table */}
            <div className="overflow-x-auto border border-stone-200 rounded-xl mb-5">
              <table className="w-full text-xs text-left">
                <thead className="bg-stone-50 text-stone-700 font-bold border-b border-stone-200">
                  <tr>
                    <th className="py-2 px-3">Size</th>
                    <th className="py-2 px-3">Bust ({sizeUnit === 'inches' ? 'in' : 'cm'})</th>
                    <th className="py-2 px-3">Waist ({sizeUnit === 'inches' ? 'in' : 'cm'})</th>
                    <th className="py-2 px-3">Length ({sizeUnit === 'inches' ? 'in' : 'cm'})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {SIZE_CHART.map((row) => (
                    <tr
                      key={row.size}
                      className={recommendedSize === row.size ? 'bg-amber-50 font-bold' : ''}
                    >
                      <td className="py-2 px-3 font-bold text-stone-900">{row.size}</td>
                      <td className="py-2 px-3 text-stone-600">
                        {sizeUnit === 'inches' ? row.bustInches : row.bustCm}
                      </td>
                      <td className="py-2 px-3 text-stone-600">
                        {sizeUnit === 'inches' ? row.waistInches : row.waistCm}
                      </td>
                      <td className="py-2 px-3 text-stone-600">
                        {sizeUnit === 'inches' ? row.lengthInches : row.lengthCm}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Smart Fit Recommender Tool */}
            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200">
              <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2">
                Smart Size Finder
              </h4>
              <p className="text-[11px] text-stone-500 mb-3">
                Enter your bust measurement to get your exact recommended size for this cut.
              </p>
              <div className="flex gap-2">
                <input
                  type="number"
                  placeholder={`Your Bust (${sizeUnit === 'inches' ? 'e.g. 34' : 'e.g. 86'})`}
                  value={userBust}
                  onChange={(e) => setUserBust(e.target.value)}
                  className="flex-1 bg-white border border-stone-300 rounded-lg px-3 py-2 text-xs text-stone-900"
                />
                <button
                  onClick={handleCalculateFit}
                  className="px-4 py-2 bg-stone-900 text-white text-xs font-bold rounded-lg hover:bg-stone-800 active:scale-95 transition-all"
                >
                  Find Size
                </button>
              </div>

              {recommendedSize && (
                <div className="mt-3 p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center justify-between">
                  <span>
                    Your ideal recommended size is <strong>{recommendedSize}</strong>.
                  </span>
                  <button
                    onClick={() => {
                      setSelectedSize(recommendedSize as Size);
                      setShowSizeGuide(false);
                    }}
                    className="underline font-bold hover:text-emerald-950"
                  >
                    Select {recommendedSize}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
