import React, { useState, useEffect } from 'react';
import { Send, Check, ShieldCheck, Heart, ExternalLink, Settings, MessageCircle } from 'lucide-react';
import { subscribeToWhatsAppConfig } from '../services/firebase';

interface FooterProps {
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [waNumber, setWaNumber] = useState('917545936515');
  const [waMessage, setWaMessage] = useState('I want new id with 10% welcome bonus');

  useEffect(() => {
    const unsub = subscribeToWhatsAppConfig((cfg) => {
      if (cfg.number) setWaNumber(cfg.number);
      if (cfg.message) setWaMessage(cfg.message);
    });
    return () => {
      if (unsub) unsub();
    };
  }, []);

  const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(waMessage)}`;

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
    setTimeout(() => {
      setEmail('');
      setSubscribed(false);
    }, 3000);
  };

  return (
    <footer className="bg-stone-950 text-stone-300 pt-16 pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-stone-800">
          {/* Brand & Mission Column */}
          <div className="lg:col-span-2 space-y-4">
            <span className="font-display text-2xl font-extrabold tracking-widest text-white uppercase block">
              ORGAVO
            </span>
            <p className="text-xs text-stone-400 leading-relaxed max-w-sm">
              India's trendiest fast-fashion destination for aesthetic tops, viral corsets, knitwear, and Gen-Z streetwear. Designed to empower everyday style with inclusive fits and affordable luxury.
            </p>

            {/* Newsletter form */}
            <div className="pt-2">
              <span className="text-xs font-semibold text-white uppercase tracking-wider block mb-2">
                Get 10% Off Your First Order
              </span>
              <form onSubmit={handleSubscribe} className="flex gap-2 max-w-md">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="flex-1 bg-stone-900 border border-stone-700 rounded-lg px-3 py-2 text-xs text-white placeholder:text-stone-500 focus:outline-none focus:border-stone-400"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-white text-stone-950 hover:bg-stone-200 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer"
                >
                  {subscribed ? <Check className="w-3.5 h-3.5" /> : <Send className="w-3.5 h-3.5" />}
                  <span>{subscribed ? 'Subscribed' : 'Join'}</span>
                </button>
              </form>
              {subscribed && (
                <p className="text-[11px] text-emerald-400 mt-1.5">
                  Welcome to Orgavo fam! Code <strong>TRENDY10</strong> is ready for you.
                </p>
              )}
            </div>
          </div>

          {/* Column 2: Tops Collections */}
          <div>
            <h4 className="font-bold text-xs uppercase tracking-wider text-white mb-4">
              Tops Collections
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li><a href="#corsets" className="hover:text-white transition-colors">Sculpted Corsets</a></li>
              <li><a href="#babytees" className="hover:text-white transition-colors">90s Baby Tees</a></li>
              <li><a href="#knitwear" className="hover:text-white transition-colors">Summer Knits & Cardigans</a></li>
              <li><a href="#blouses" className="hover:text-white transition-colors">Cottagecore Blouses</a></li>
              <li><a href="#halters" className="hover:text-white transition-colors">Halter & Cami Tops</a></li>
              <li><a href="#party" className="hover:text-white transition-colors">Night Out & Party Wear</a></li>
            </ul>
          </div>

          {/* Column 3: Customer Care */}
          <div>
            <h4 className="font-bold text-xs uppercase tracking-wider text-white mb-4">
              Customer Support
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li><span className="hover:text-white cursor-pointer">Track Your Order</span></li>
              <li><span className="hover:text-white cursor-pointer">Size Guide & Sizing Help</span></li>
              <li><span className="hover:text-white cursor-pointer">7-Day Return & Exchange</span></li>
              <li><span className="hover:text-white cursor-pointer">Shipping & Delivery Times</span></li>
              <li><span className="hover:text-white cursor-pointer">FAQ & Help Center</span></li>
              <li>
                <a
                  href={waUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="js-whatsapp text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5 font-medium transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  Chat on WhatsApp
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Trust & Policies & Admin */}
          <div>
            <h4 className="font-bold text-xs uppercase tracking-wider text-white mb-4">
              Store & Admin
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li><span className="hover:text-white cursor-pointer">100% Secure Payments</span></li>
              <li><span className="hover:text-white cursor-pointer">Cash on Delivery (COD)</span></li>
              <li><span className="hover:text-white cursor-pointer">Privacy Policy</span></li>
              <li>
                <a
                  href="admin.html"
                  className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 transition-colors group"
                >
                  <span>🔐 Admin Page (admin.html)</span>
                  <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                </a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenAdmin}
                  className="text-stone-300 hover:text-amber-400 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Settings className="w-3 h-3" />
                  Quick Admin Modal
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Payment Badges */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div className="flex items-center gap-1">
            <span>© {new Date().getFullYear()} Orgavo India. All rights reserved.</span>
            <span>·</span>
            <span className="flex items-center gap-1">
              Crafted with <Heart className="w-3 h-3 text-rose-500 fill-current" /> in India
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-stone-400 font-medium">
            <span className="px-2 py-0.5 bg-stone-900 border border-stone-800 rounded">UPI</span>
            <span className="px-2 py-0.5 bg-stone-900 border border-stone-800 rounded">GPay</span>
            <span className="px-2 py-0.5 bg-stone-900 border border-stone-800 rounded">PhonePe</span>
            <span className="px-2 py-0.5 bg-stone-900 border border-stone-800 rounded">Paytm</span>
            <span className="px-2 py-0.5 bg-stone-900 border border-stone-800 rounded">Visa / RuPay</span>
            <span className="px-2 py-0.5 bg-stone-900 border border-stone-800 rounded">Cash on Delivery</span>
          </div>
        </div>

        {/* Dedicated Admin Panel Access Bar at the very bottom */}
        <div className="mt-8 pt-4 border-t border-stone-800/80 bg-stone-900/60 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-stone-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-semibold text-stone-200">Orgavo Store Admin (Real-Time Database Connected):</span>
            <span className="text-[11px] text-stone-400">Manage real customer orders, product prices, stock status, and add new tops.</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <a
              href="admin.html"
              className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold rounded-lg text-xs flex items-center gap-1 shadow-sm transition-all"
            >
              <span>admin.html खोलें</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <button
              type="button"
              onClick={onOpenAdmin}
              className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold rounded-lg text-xs transition-colors cursor-pointer"
            >
              एडमिन पैनल (Modal)
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
