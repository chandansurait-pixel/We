import React, { useState, useEffect } from 'react';
import { 
  X, 
  Package, 
  ShoppingBag, 
  Plus, 
  Trash2, 
  Save, 
  CheckCircle2, 
  Clock, 
  Phone, 
  MapPin, 
  DollarSign, 
  Tag, 
  Settings, 
  Eye, 
  Edit3, 
  ArrowLeft,
  AlertCircle,
  Truck,
  MessageSquare
} from 'lucide-react';
import { Product, Size } from '../types';
import { 
  subscribeToOrders, 
  updateOrderStatusInFirebase, 
  saveProductToFirebase, 
  deleteProductFromFirebase, 
  updateProductFieldInFirebase,
  subscribeToWhatsAppConfig,
  saveWhatsAppConfigToFirebase
} from '../services/firebase';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose, products }) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'add' | 'settings'>('orders');
  const [orders, setOrders] = useState<any[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);
  const [toast, setToast] = useState<string | null>(null);

  // WhatsApp Config state
  const [whatsappNumber, setWhatsappNumber] = useState('917545936515');
  const [whatsappMessage, setWhatsappMessage] = useState('I want new id with 10% welcome bonus');

  // New Product Form State
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    category: 'Tops',
    subCategory: 'Corsets',
    price: 899,
    originalPrice: 1499,
    discountPercent: 40,
    fitType: 'Fitted',
    inStock: true,
    description: '',
    images: ['https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80'],
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    sizeStock: { XS: 5, S: 5, M: 5, L: 5, XL: 2, XXL: 0 },
    colors: [{ name: 'Ivory White', hex: '#FAF7F2', imageIndex: 0 }],
  });
  const [newImageUrl, setNewImageUrl] = useState('');

  // Editable Product state in list
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editOriginalPrice, setEditOriginalPrice] = useState<number>(0);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  useEffect(() => {
    if (!isOpen) return;

    // Real-time Orders Listener from Firebase
    const unsubscribeOrders = subscribeToOrders((liveOrders) => {
      setOrders(liveOrders);
      setLoadingOrders(false);
    });

    // Real-time WhatsApp config
    const unsubscribeWhatsApp = subscribeToWhatsAppConfig((cfg) => {
      if (cfg.number) setWhatsappNumber(cfg.number);
      if (cfg.message) setWhatsappMessage(cfg.message);
    });

    return () => {
      if (unsubscribeOrders) unsubscribeOrders();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      await updateOrderStatusInFirebase(orderId, newStatus);
      showToast(`Order status updated to "${newStatus}"`);
    } catch (err) {
      console.error(err);
      showToast('Error updating order');
    }
  };

  const handleToggleStock = async (prod: Product) => {
    try {
      await updateProductFieldInFirebase(prod.id, { inStock: !prod.inStock });
      showToast(`${prod.name} stock status updated!`);
    } catch (err) {
      console.error(err);
      showToast('Error updating stock');
    }
  };

  const handleSavePriceEdit = async (productId: string) => {
    try {
      const discount = Math.round(((editOriginalPrice - editPrice) / editOriginalPrice) * 100);
      await updateProductFieldInFirebase(productId, { 
        price: editPrice, 
        originalPrice: editOriginalPrice,
        discountPercent: Math.max(0, discount)
      });
      setEditingProductId(null);
      showToast('Price updated in Firebase successfully!');
    } catch (err) {
      console.error(err);
      showToast('Error updating price');
    }
  };

  const handleDeleteProduct = async (productId: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete "${name}" from store?`)) return;
    try {
      await deleteProductFromFirebase(productId);
      showToast(`Product deleted from store.`);
    } catch (err) {
      console.error(err);
      showToast('Error deleting product');
    }
  };

  const handleAddProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.price) {
      alert('Please fill product name and price');
      return;
    }

    const id = `org-${Date.now()}`;
    const discount = Math.round(
      (((newProduct.originalPrice || 1499) - (newProduct.price || 899)) / (newProduct.originalPrice || 1499)) * 100
    );

    const fullProduct: Product = {
      id,
      name: newProduct.name || 'New Top',
      handle: (newProduct.name || 'new-top').toLowerCase().replace(/\s+/g, '-'),
      category: 'Tops',
      subCategory: (newProduct.subCategory as any) || 'Corsets',
      price: Number(newProduct.price),
      originalPrice: Number(newProduct.originalPrice || newProduct.price * 1.5),
      discountPercent: Math.max(0, discount),
      colors: newProduct.colors || [{ name: 'Classic', hex: '#111827', imageIndex: 0 }],
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      sizeStock: { XS: 5, S: 5, M: 5, L: 5, XL: 2, XXL: 0 },
      inStock: true,
      rating: 5.0,
      reviewCount: 1,
      images: newImageUrl ? [newImageUrl] : (newProduct.images || []),
      description: newProduct.description || 'Premium aesthetic top crafted with breathable fabric.',
      fabricDetails: ['Cotton blend', 'Comfort stretch', 'Dry clean or machine wash'],
      fitType: (newProduct.fitType as any) || 'Fitted',
      modelInfo: "Model is 5'6 wearing size S",
      styleTips: 'Pair with relaxed denim or trousers',
      reviews: [],
    };

    try {
      await saveProductToFirebase(fullProduct);
      showToast(`Product "${fullProduct.name}" uploaded to Firebase!`);
      setActiveTab('products');
      setNewProduct({
        name: '',
        category: 'Tops',
        subCategory: 'Corsets',
        price: 899,
        originalPrice: 1499,
        discountPercent: 40,
        fitType: 'Fitted',
        inStock: true,
        description: '',
        images: ['https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80'],
      });
      setNewImageUrl('');
    } catch (err) {
      console.error(err);
      showToast('Error uploading product');
    }
  };

  const handleSaveWhatsApp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await saveWhatsAppConfigToFirebase(whatsappNumber, whatsappMessage);
      showToast('WhatsApp settings updated in Firebase!');
    } catch (err) {
      console.error(err);
      showToast('Error updating WhatsApp settings');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-6 right-6 z-60 bg-stone-900 text-white px-4 py-2.5 rounded-xl shadow-2xl text-xs font-semibold flex items-center gap-2 border border-stone-700 animate-slideUp">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toast}</span>
        </div>
      )}

      {/* Admin Panel Modal Card */}
      <div className="relative w-full max-w-6xl bg-stone-900 text-stone-100 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[94vh] border border-stone-800">
        {/* Top Bar Header */}
        <div className="p-4 sm:p-5 border-b border-stone-800 flex items-center justify-between bg-stone-950">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-400 text-stone-950 rounded-xl">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-lg font-bold text-white tracking-wide">
                  ORGAVO LIVE ADMIN
                </h2>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                  Firebase Connected
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Real-time Orders, Product Catalog & Store Control
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-white rounded-xl hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center border-b border-stone-800 px-4 bg-stone-950/60 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-3 px-4 text-xs font-bold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'orders'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-stone-400 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Orders Received ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`py-3 px-4 text-xs font-bold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'products'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-stone-400 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Manage Products ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('add')}
            className={`py-3 px-4 text-xs font-bold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'add'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-stone-400 hover:text-white'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>Upload New Top</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3 px-4 text-xs font-bold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'settings'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-stone-400 hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>WhatsApp & Store Settings</span>
          </button>
        </div>

        {/* Tab 1: LIVE ORDERS */}
        {activeTab === 'orders' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Incoming Customer Orders</h3>
                <p className="text-xs text-stone-400">All orders placed on the store update here in real time</p>
              </div>
              <span className="text-xs text-stone-400">
                Total Orders: <strong className="text-white">{orders.length}</strong>
              </span>
            </div>

            {loadingOrders ? (
              <div className="py-20 text-center text-stone-400 text-xs">
                Connecting to Firebase Database...
              </div>
            ) : orders.length === 0 ? (
              <div className="py-20 text-center bg-stone-950/40 rounded-2xl border border-stone-800 space-y-3">
                <ShoppingBag className="w-10 h-10 text-stone-600 mx-auto" />
                <h4 className="text-sm font-bold text-stone-300">No orders received yet</h4>
                <p className="text-xs text-stone-500 max-w-sm mx-auto">
                  When a customer completes checkout on your store, their order details, shipping address, and payment method will instantly appear here!
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((order: any) => (
                  <div
                    key={order.orderId}
                    className="p-4 sm:p-5 bg-stone-950/80 rounded-2xl border border-stone-800 space-y-4"
                  >
                    {/* Order Header */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-stone-800">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-amber-400">
                          {order.orderId}
                        </span>
                        <span className="text-stone-500">·</span>
                        <span className="text-xs text-stone-400">{order.createdAt}</span>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-xs font-bold text-white">
                          Amount: <span className="text-emerald-400">₹{order.total}</span>
                        </span>
                        {/* Status selector */}
                        <select
                          value={order.status || 'Pending'}
                          onChange={(e) => handleStatusChange(order.orderId, e.target.value)}
                          className={`text-xs font-bold px-2.5 py-1 rounded-lg border focus:outline-none cursor-pointer ${
                            order.status === 'Delivered'
                              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                              : order.status === 'Shipped'
                              ? 'bg-blue-500/20 text-blue-400 border-blue-500/40'
                              : order.status === 'Cancelled'
                              ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                              : 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                          }`}
                        >
                          <option value="Pending">⏳ Pending</option>
                          <option value="Confirmed">✅ Confirmed</option>
                          <option value="Shipped">🚚 Shipped</option>
                          <option value="Delivered">🎉 Delivered</option>
                          <option value="Cancelled">❌ Cancelled</option>
                        </select>
                      </div>
                    </div>

                    {/* Customer & Shipping Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div className="space-y-1 bg-stone-900/60 p-3 rounded-xl border border-stone-800/80">
                        <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block mb-1">
                          Customer & Delivery Info
                        </span>
                        <p className="font-bold text-white text-sm">
                          {order.shippingAddress?.fullName}
                        </p>
                        <p className="text-stone-300 flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-stone-500" />
                          <span>+91 {order.shippingAddress?.phone}</span>
                          <a
                            href={`https://wa.me/91${order.shippingAddress?.phone}?text=Hello%20${encodeURIComponent(order.shippingAddress?.fullName || '')},%20regarding%20your%20order%20${order.orderId}%20at%20Orgavo...`}
                            target="_blank"
                            rel="noreferrer"
                            className="ml-2 text-emerald-400 hover:underline font-semibold"
                          >
                            WhatsApp Chat
                          </a>
                        </p>
                        <p className="text-stone-300 flex items-start gap-1.5 pt-1">
                          <MapPin className="w-3.5 h-3.5 text-stone-500 shrink-0 mt-0.5" />
                          <span>
                            {order.shippingAddress?.street}, {order.shippingAddress?.city},{' '}
                            {order.shippingAddress?.state} - <strong>{order.shippingAddress?.pincode}</strong>
                          </span>
                        </p>
                        <p className="text-[11px] text-stone-400 pt-1">
                          Payment: <strong className="text-white">{order.paymentMethod}</strong>
                        </p>
                      </div>

                      {/* Items Ordered */}
                      <div className="space-y-2 bg-stone-900/60 p-3 rounded-xl border border-stone-800/80">
                        <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                          Items in Order ({order.items?.length || 0})
                        </span>
                        <div className="space-y-2 max-h-36 overflow-y-auto">
                          {order.items?.map((item: any, i: number) => (
                            <div key={i} className="flex items-center justify-between text-xs py-1 border-b border-stone-800/60 last:border-0">
                              <div className="flex items-center gap-2">
                                <img
                                  src={item.product?.images?.[0]}
                                  alt={item.product?.name}
                                  className="w-8 h-10 object-cover rounded bg-stone-800"
                                />
                                <div>
                                  <p className="font-medium text-white line-clamp-1">{item.product?.name}</p>
                                  <p className="text-[10px] text-stone-400">
                                    Size: <strong>{item.selectedSize}</strong> | Color: {item.selectedColor?.name} | Qty: {item.quantity}
                                  </p>
                                </div>
                              </div>
                              <span className="font-bold text-stone-200 tabular-nums">
                                ₹{item.product?.price * item.quantity}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: MANAGE PRODUCTS & PRICE / STOCK */}
        {activeTab === 'products' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Live Product Catalog & Stock Controls</h3>
                <p className="text-xs text-stone-400">
                  Click on price to edit, toggle in-stock / out-of-stock, or delete products.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('add')}
                className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Top</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {products.map((prod) => (
                <div
                  key={prod.id}
                  className="p-4 bg-stone-950/70 rounded-2xl border border-stone-800 flex gap-4 items-start"
                >
                  <img
                    src={prod.images[0]}
                    alt={prod.name}
                    className="w-20 h-26 object-cover rounded-xl bg-stone-800 shrink-0"
                  />

                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-stone-500">
                          {prod.subCategory}
                        </span>
                        <h4 className="text-xs font-bold text-white truncate max-w-[200px]">
                          {prod.name}
                        </h4>
                      </div>

                      {/* Delete button */}
                      <button
                        onClick={() => handleDeleteProduct(prod.id, prod.name)}
                        className="text-stone-500 hover:text-rose-400 p-1 transition-colors"
                        title="Delete product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Price editor */}
                    {editingProductId === prod.id ? (
                      <div className="p-2 bg-stone-900 rounded-lg space-y-2 border border-stone-700">
                        <div className="flex gap-2">
                          <div>
                            <label className="text-[10px] text-stone-400">Selling Price (₹)</label>
                            <input
                              type="number"
                              value={editPrice}
                              onChange={(e) => setEditPrice(Number(e.target.value))}
                              className="w-full bg-stone-800 border border-stone-700 rounded px-2 py-1 text-xs text-white"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-stone-400">MRP (₹)</label>
                            <input
                              type="number"
                              value={editOriginalPrice}
                              onChange={(e) => setEditOriginalPrice(Number(e.target.value))}
                              className="w-full bg-stone-800 border border-stone-700 rounded px-2 py-1 text-xs text-white"
                            />
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleSavePriceEdit(prod.id)}
                            className="flex-1 py-1 bg-emerald-500 text-stone-950 font-bold text-xs rounded hover:bg-emerald-400"
                          >
                            Save Price
                          </button>
                          <button
                            onClick={() => setEditingProductId(null)}
                            className="py-1 px-2 bg-stone-800 text-stone-400 text-xs rounded hover:text-white"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between">
                        <div className="flex items-baseline gap-2">
                          <span className="text-sm font-bold text-white tabular-nums">
                            ₹{prod.price}
                          </span>
                          <span className="text-xs text-stone-500 line-through tabular-nums">
                            ₹{prod.originalPrice}
                          </span>
                          <span className="text-[10px] text-emerald-400 font-bold">
                            {prod.discountPercent}% OFF
                          </span>
                        </div>
                        <button
                          onClick={() => {
                            setEditingProductId(prod.id);
                            setEditPrice(prod.price);
                            setEditOriginalPrice(prod.originalPrice);
                          }}
                          className="text-[11px] text-amber-400 hover:underline flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit Price</span>
                        </button>
                      </div>
                    )}

                    {/* Stock toggle */}
                    <div className="flex items-center justify-between pt-1 border-t border-stone-800/80">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-stone-400">Stock Status:</span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            prod.inStock
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-rose-500/20 text-rose-400'
                          }`}
                        >
                          {prod.inStock ? 'In Stock' : 'Out of Stock'}
                        </span>
                      </div>
                      <button
                        onClick={() => handleToggleStock(prod)}
                        className="text-[11px] font-medium text-stone-300 hover:text-white underline cursor-pointer"
                      >
                        {prod.inStock ? 'Mark Out of Stock' : 'Mark In Stock'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: UPLOAD NEW TOP */}
        {activeTab === 'add' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 max-w-2xl mx-auto w-full">
            <h3 className="text-base font-bold text-white mb-1">Upload New Top to Catalog</h3>
            <p className="text-xs text-stone-400 mb-6">
              Enter product details. It will immediately be saved to Firebase and appear live on your store.
            </p>

            <form onSubmit={handleAddProductSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  required
                  value={newProduct.name}
                  onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                  placeholder="e.g. Velvet Night Sweetheart Corset Top"
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-300 mb-1">
                    Silhouette / Sub-Category
                  </label>
                  <select
                    value={newProduct.subCategory}
                    onChange={(e) => setNewProduct({ ...newProduct, subCategory: e.target.value as any })}
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="Corsets">Corsets</option>
                    <option value="Baby Tees">Baby Tees</option>
                    <option value="Knitwear">Knitwear</option>
                    <option value="Blouses">Blouses</option>
                    <option value="Halters & Camis">Halters & Camis</option>
                    <option value="Party Tops">Party Tops</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-300 mb-1">
                    Fit Type
                  </label>
                  <select
                    value={newProduct.fitType}
                    onChange={(e) => setNewProduct({ ...newProduct, fitType: e.target.value as any })}
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="Fitted">Fitted</option>
                    <option value="Cropped">Cropped</option>
                    <option value="Relaxed">Relaxed</option>
                    <option value="Regular">Regular</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-300 mb-1">
                    Selling Price (INR) *
                  </label>
                  <input
                    type="number"
                    required
                    value={newProduct.price}
                    onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
                    placeholder="899"
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-300 mb-1">
                    Original Price / MRP (INR)
                  </label>
                  <input
                    type="number"
                    value={newProduct.originalPrice}
                    onChange={(e) => setNewProduct({ ...newProduct, originalPrice: Number(e.target.value) })}
                    placeholder="1499"
                    className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1">
                  Product Image URL
                </label>
                <input
                  type="url"
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                  placeholder="https://example.com/photo.jpg (leave empty for aesthetic default)"
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1">
                  Description
                </label>
                <textarea
                  rows={3}
                  value={newProduct.description}
                  onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                  placeholder="Briefly describe fabric, cut, and vibe..."
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer"
              >
                Upload & Publish to Firebase
              </button>
            </form>
          </div>
        )}

        {/* Tab 4: WHATSAPP & STORE SETTINGS */}
        {activeTab === 'settings' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 max-w-2xl mx-auto w-full space-y-6">
            <div>
              <h3 className="text-base font-bold text-white mb-1">Live WhatsApp Integration</h3>
              <p className="text-xs text-stone-400">
                Connected to your Firebase Realtime Database config path: <code>config/whatsappNumber</code> and <code>config/whatsappMessage</code>.
              </p>
            </div>

            <form onSubmit={handleSaveWhatsApp} className="p-5 bg-stone-950 rounded-2xl border border-stone-800 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1">
                  WhatsApp Support Phone Number (with Country Code)
                </label>
                <input
                  type="text"
                  required
                  value={whatsappNumber}
                  onChange={(e) => setWhatsappNumber(e.target.value)}
                  placeholder="917545936515"
                  className="w-full bg-stone-900 border border-stone-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
                />
                <span className="text-[11px] text-stone-500 mt-1 block">
                  Example: 917545936515 (91 for India)
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1">
                  Default Pre-filled Message
                </label>
                <textarea
                  rows={2}
                  required
                  value={whatsappMessage}
                  onChange={(e) => setWhatsappMessage(e.target.value)}
                  placeholder="I want new id with 10% welcome bonus"
                  className="w-full bg-stone-900 border border-stone-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <a
                  href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-bold text-emerald-400 hover:underline flex items-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Test WhatsApp Link</span>
                </a>

                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Save to Firebase
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
